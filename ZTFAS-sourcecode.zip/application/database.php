<?php


return [
    // Database type
    'type'            => 'mysql',
    // Server address
    'hostname'        => '127.0.0.1',
    // Database name
    'database'        => 'caigou_netdisk_m',
    // Username
    'username'        => 'caigou_netdisk_m',
    // Password
    'password'        => '9nM1scSMW6nSxQfb',
    // Port
    'hostport'        => '3306',
    // Connection DSN
    'dsn'             => '',
    // Database connection parameters
    'params'          => [],
    // Database encoding defaults to utf8
    'charset'         => 'utf8',
    // Database table prefix
    'prefix'          => 'sd_',
    // Database debug mode
    'debug'           => true,
    // Database deployment method: 0 centralized (single server), 1 distributed (master-slave servers)
    'deploy'          => 0,
    // Whether to separate reading and writing for the database, effective in master-slave mode
    'rw_separate'     => false,
    // Number of main servers after read-write separation
    'master_num'      => 1,
    // Specify slave server sequence number
    'slave_no'        => '',
    // Whether to strictly check if fields exist
    'fields_strict'   => true,
    // Data set return type
    'resultset_type'  => 'array',
    // Automatically write timestamp fields
    'auto_timestamp'  => false,
    // Default time format for extracted time fields
    'datetime_format' => 'Y-m-d H:i:s',
    // Whether to conduct SQL performance analysis
    'sql_explain'     => false,
];