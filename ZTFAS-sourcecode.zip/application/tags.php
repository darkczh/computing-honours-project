<?php


return [
    'app_init'     => [],
    'app_begin'    => [],
    'module_init'  => [],
    'action_begin' => [],
    'view_filter'  => [],
    'log_write'    => [],
    'app_end'      => [],
];
