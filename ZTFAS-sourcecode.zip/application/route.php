<?php

use think\Route;
Route::rule([
	'Upload/mkblk/:chunkSize'=>'index/Upload/chunk',
	'Upload/mkfile/:fileSize/key/:keyValue/fname/:fname/path/:path'=>'index/Upload/mkFile',
	's/:key'=>'index/Share/index',
	'Share/Download/:key'=>'index/Share/Download',
	'Share/Preview/:key'=>'index/Share/Preview',
	'Share/ListFile/:key'=>'index/Share/ListFile',
	'Login'=>'index/Member/LoginForm',
	'Member/emailActivate/:key'=>'index/Member/emailActivate',
	'Member/resetPwd/:key'=>'index/Member/resetPwd',
	'Callback/Payment/Jinshajiang' => 'index/Callback/Jinshajiang',
	'Explore/S/:key' => 'index/Explore/S',
	'Member/Avatar/:uid/:size' => ['Member/Avatar',[],['uid'=>'\d+']],
	'Profile/:uid' => ['Profile/index',[],['uid'=>'\d+']],
	'Callback/Payment/Jinshajiang' => 'index/Callback/Jinshajiang',
]);