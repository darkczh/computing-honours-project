<?php  
namespace app\index\model;

use think\Model;
use think\Db;
use OSS\OssClient;
use OSS\Core\OssException;
use \app\index\model\Option;

/**
* Alibaba Cloud OSS strategy file management adapter
*/
class OssAdapter extends Model {
    private $fileModel;
    private $policyModel;
    private $userModel;

    public function __construct($file, $policy, $user) {
        $this->fileModel = $file;
        $this->policyModel = $policy;
        $this->userModel = $user;
    }

    /**
    * Get the content of the OSS strategy text file
    *
    * @return string File content
    */
    public function getFileContent() {
        return file_get_contents($this->Preview()[1]);
    }

    /**
    * Sign the OSS preview URL
    *
    * @return void
    */
    public function Preview() {
        if (!$this->policyModel['bucket_private']) {
            $fileUrl = $this->policyModel["url"] . $this->fileModel["pre_name"];
            return [true, $fileUrl];
        } else {
            $accessKeyId = $this->policyModel["ak"];
            $accessKeySecret = $this->policyModel["sk"];
            $endpoint = $this->policyModel["url"];
            try {
                $ossClient = new OssClient($accessKeyId, $accessKeySecret, $endpoint, true);
            } catch (OssException $e) {
                return [false, 0];
            }
            $baseUrl = $this->policyModel["url"] . $this->fileModel["pre_name"];
            try {
                $signedUrl = $ossClient->signUrl($this->policyModel["bucketname"], $this->fileModel["pre_name"], Option::getValue("timeout"));
            } catch (OssException $e) {
                return [false, 0];
            }
            return [true, $signedUrl];
        }
    }

    /**
    * Save the content of the OSS file
    *
    * @param string $content File content
    * @return void
    */
    public function saveContent($content) {
        $accessKeyId = $this->policyModel["ak"];
        $accessKeySecret = $this->policyModel["sk"];
        $endpoint = "http" . ltrim(ltrim($this->policyModel["server"], "https"), "http");
        try {
            $ossClient = new OssClient($accessKeyId, $accessKeySecret, $endpoint, true);
        } catch (OssException $e) {
            die('{ "result": { "success": false, "error": "Authentication failed" } }');
        }
        try {
            $ossClient->putObject($this->policyModel["bucketname"], $this->fileModel["pre_name"], $content);
        } catch (OssException $e) {
            die('{ "result": { "success": false, "error": "Edit failed" } }');
        }
    }

    /**
    * Get the thumbnail address
    *
    * @return string Thumbnail address
    */
    public function getThumb() {
        if (!$this->policyModel['bucket_private']) {
            $fileUrl = $this->policyModel["url"] . $this->fileModel["pre_name"] . "?x-oss-process=image/resize,m_lfit,h_39,w_90";
            return [true, $fileUrl];
        } else {
            $accessKeyId = $this->policyModel["ak"];
            $accessKeySecret = $this->policyModel["sk"];
            $endpoint = $this->policyModel["url"];
            try {
                $ossClient = new OssClient($accessKeyId, $accessKeySecret, $endpoint, true);
            } catch (OssException $e) {
                return [false, 0];
            }
            $baseUrl = $this->policyModel["url"] . $this->fileModel["pre_name"];
            try {
                $signedUrl = $ossClient->signUrl($this->policyModel["bucketname"], $this->fileModel["pre_name"], Option::getValue("timeout"), 'GET', array("x-oss-process" => 'image/resize,m_lfit,h_39,w_90'));
            } catch (OssException $e) {
                return [false, 0];
            }
            return [true, $signedUrl];
        }
    }

    /**
    * Delete specified OSS file under a certain policy
    *
    * @param array $fileList   Database records of files to be deleted
    * @param array $policyData Upload policy information for the files to be deleted
    * @return void
    */
    static function DeleteFile($fileList, $policyData) {
        $accessKeyId = $policyData["ak"];
        $accessKeySecret = $policyData["sk"];
        $endpoint = "http" . ltrim(ltrim($policyData["server"], "https"), "http");
        
        try {
            $ossClient = new OssClient($accessKeyId, $accessKeySecret, $endpoint, true);
        } catch (OssException $e) {
            return false;
        }

        try {
            $ossClient->deleteObjects($policyData["bucketname"], array_column($fileList, 'pre_name'));
        } catch (OssException $e) {
            return false;
        }
    }

    /**
    * Generate file download URL
    *
    * @return array
    */
    public function Download() {
        if (!$this->policyModel['bucket_private']) {
            return [true, "/File/OssDownload?url=" . urlencode($this->policyModel["url"] . $this->fileModel["pre_name"]) . "&name=" . urlencode($this->fileModel["orign_name"])];
        } else {
            $accessKeyId = $this->policyModel["ak"];
            $accessKeySecret = $this->policyModel["sk"];
            $endpoint = $this->policyModel["url"];

            try {
                $ossClient = new OssClient($accessKeyId, $accessKeySecret, $endpoint, true);
            } catch (OssException $e) {
                return [false, 0];
            }
            $baseUrl = $this->policyModel["url"] . $this->fileModel["pre_name"];
            try {
                $signedUrl = $ossClient->signUrl($this->policyModel["bucketname"], $this->fileModel["pre_name"], Option::getValue("timeout"), 'GET', array("response-content-disposition" => 'attachment; filename=' . $this->fileModel["orign_name"]));
            } catch (OssException $e) {
                return [false, 0];
            }
            return [true, $signedUrl];
        }
    }

    /**
    * Delete temporary file
    *
    * @param string $fname File name
    * @param array $policy Upload policy information
    * @return boolean
    */
    static function deleteOssFile($fname, $policy) {
        $accessKeyId = $policy["ak"];
        $accessKeySecret = $policy["sk"];
        $endpoint = "http" . ltrim(ltrim($policy["server"], "https"), "http");

        try {
            $ossClient = new OssClient($accessKeyId, $accessKeySecret, $endpoint, true);
        } catch (OssException $e) {
            return false;
        }

        try {
            $ossClient->deleteObject($policy["bucketname"], $fname);
        } catch (OssException $e) {
            return false;
        }
        return true;
    }

    /**
    * Generate a signed temporary URL for Office preview
    *
    * @return array
    */
    public function signTmpUrl() {
        return $this->Preview();
    }
}
?>