<?php  
namespace app\index\model;

use think\Model;
use think\Db;
require_once 'extend/Qiniu/functions.php';
use Qiniu\Auth;
use \app\index\model\Option;

/**
* Qiniu strategy file management adapter
*/
class QiniuAdapter extends Model {
    private $fileModel;
    private $policyModel;
    private $userModel;

    public function __construct($file, $policy, $user) {
        $this->fileModel = $file;
        $this->policyModel = $policy;
        $this->userModel = $user;
    }

    /**
    * Get the content of the text file
    *
    * @return string File content
    */
    public function getFileContent() {
        return file_get_contents($this->Preview()[1]);
    }

    /**
    * Sign Qiniu file preview URL
    *
    * @param string $thumb Thumbnail parameters
    * @return void
    */
    public function Preview($thumb = null) {
        if ($thumb === true || $thumb === false) {
            $thumb = null;
        }
        if (!$this->policyModel['bucket_private']) {
            $fileUrl = $this->policyModel["url"] . $this->fileModel["pre_name"] . $thumb;
            return [true, $fileUrl];
        } else {
            $auth = new Auth($this->policyModel["ak"], $this->policyModel["sk"]);
            $baseUrl = $this->policyModel["url"] . $this->fileModel["pre_name"] . $thumb;
            $signedUrl = $auth->privateDownloadUrl($baseUrl);
            return [true, $signedUrl];
        }
    }

    /**
    * Save Qiniu file content
    *
    * @param string $content File content
    * @return bool
    */
    public function saveContent($content) {
        $auth = new Auth($this->policyModel["ak"], $this->policyModel["sk"]);
        $expires = 3600;
        $keyToOverwrite = $this->fileModel["pre_name"];
        $upToken = $auth->uploadToken($this->policyModel["bucketname"], $keyToOverwrite, $expires, null, true);
        $uploadMgr = new \Qiniu\Storage\UploadManager();
        list($ret, $err) = $uploadMgr->put($upToken, $keyToOverwrite, $content);
        
        if ($err !== null) {
            die('{ "result": { "success": false, "error": "Edit failed" } }');
        } else {
            return true;
        }
    }

    /**
    * Get thumbnail address
    *
    * @return string Thumbnail address
    */
    public function getThumb() {
        return $this->Preview("?imageView2/2/w/90/h/39");
    }

    /**
    * Delete specified Qiniu file under a certain policy
    *
    * @param array $fileList   Database records of files to be deleted
    * @param array $policyData Upload policy information for the files to be deleted
    * @return void
    */
    static function DeleteFile($fileList, $policyData) {
        $auth = new Auth($policyData["ak"], $policyData["sk"]);
        $config = new \Qiniu\Config();
        $bucketManager = new \Qiniu\Storage\BucketManager($auth);
        $fileListTemp = array_column($fileList, 'pre_name');
        $ops = $bucketManager->buildBatchDelete($policyData["bucketname"], $fileListTemp);
        list($ret, $err) = $bucketManager->batch($ops);
    }

    /**
    * Generate file download URL
    *
    * @return array
    */
    public function Download() {
        if (!$this->policyModel['bucket_private']) {
            $fileUrl = $this->policyModel["url"] . $this->fileModel["pre_name"] . "?attname=" . urlencode($this->fileModel["orign_name"]);
            return [true, $fileUrl];
        } else {
            $auth = new Auth($this->policyModel["ak"], $this->policyModel["sk"]);
            $baseUrl = $this->policyModel["url"] . $this->fileModel["pre_name"] . "?attname=" . urlencode($this->fileModel["orign_name"]);
            $signedUrl = $auth->privateDownloadUrl($baseUrl);
            return [true, $signedUrl];
        }
    }

    /**
    * Delete temporary file
    *
    * @param string $fname File name
    * @param array $policy Upload policy information
    * @return void
    */
    static function deleteSingle($fname, $policy) {
        $auth = new Auth($policy["ak"], $policy["sk"]);
        $config = new \Qiniu\Config();
        $bucketManager = new \Qiniu\Storage\BucketManager($auth);
        $err = $bucketManager->delete($policy["bucketname"], $fname);
        return !$err;
    }

    /**
    * Sign a temporary URL for Office preview
    *
    * @return array
    */
    public function signTmpUrl() {
        return $this->Preview();
    }
}
?>