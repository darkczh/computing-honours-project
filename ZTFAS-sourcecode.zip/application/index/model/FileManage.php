<?php
namespace app\index\model;

use think\Model;
use think\Db;
use think\Validate;
use \app\index\model\Option;

class FileManage extends Model {
    public $filePath;
    public $fileData;
    public $userID;
    public $userData;
    public $policyData;
    public $deleteStatus = true;
    private $adapter;

    /**
    * Constructor function
    *
    * @param string $path File path/File ID
    * @param int $uid User ID
    * @param boolean $byId Whether to find file by ID
    */
    public function __construct($path, $uid, $byId = false) {
        if ($byId) {
            $fileRecord = Db::name('files')->where('id', $path)->find();
            $this->filePath = rtrim($fileRecord["dir"], "/") . "/" . $fileRecord["orign_name"];
        } else {
            $this->filePath = $path;
            $fileInfo = $this->getFileName($path);
            $fileName = $fileInfo[0];
            $path = $fileInfo[1];
            $fileRecord = Db::name('files')->where('upload_user', $uid)->where('orign_name', $fileName)->where('dir', $path)->find();
        }
        if (empty($fileRecord)) {
            die('{ "result": { "success": false, "error": "File does not exist" } }');
        }
        $this->fileData = $fileRecord;
        $this->userID = $uid;
        $this->userData = Db::name('users')->where('id', $uid)->find();
        $this->policyData = Db::name('policy')->where('id', $this->fileData["policy_id"])->find();
        switch ($this->policyData["policy_type"]) {
            case 'local':
                $this->adapter = new \app\index\model\LocalAdapter($this->fileData, $this->policyData, $this->userData);
                break;
            case 'qiniu':
                $this->adapter = new \app\index\model\QiniuAdapter($this->fileData, $this->policyData, $this->userData);
                break;
            case 'oss':
                $this->adapter = new \app\index\model\OssAdapter($this->fileData, $this->policyData, $this->userData);
                break;
            case 'upyun':
                $this->adapter = new \app\index\model\UpyunAdapter($this->fileData, $this->policyData, $this->userData);
                break;
            case 's3':
                $this->adapter = new \app\index\model\S3Adapter($this->fileData, $this->policyData, $this->userData);
                break;
            case 'remote':
                $this->adapter = new \app\index\model\RemoteAdapter($this->fileData, $this->policyData, $this->userData);
                break;
            case 'onedrive':
                $this->adapter = new \app\index\model\OnedriveAdapter($this->fileData, $this->policyData, $this->userData);
                break;
            default:
                // Handle unknown policy type
                break;
        }
    }

    /**
    * Get the external link address of the file
    *
    * @return void
    */
    public function Source() {
        if (!$this->policyData["origin_link"]) {
            die('{"url":"This file does not support obtaining the source file URL"}');
        } else {
            echo ('{"url":"' . $this->policyData["url"] . $this->fileData["pre_name"] . '"}');
        }
    }

    /**
    * Get editable file content
    *
    * @return void
    */
    public function getContent() {
        $sizeLimit = (int) Option::getValue("maxEditSize");
        if ($this->fileData["size"] > $sizeLimit) {
            die('{ "result": { "success": false, "error": "The current user group can only edit files up to ' . $sizeLimit . ' bytes"} }');
        } else {
            try {
                $fileContent = $this->adapter->getFileContent();
            } catch (\Exception $e) {
                die('{ "result": { "success": false, "error": "' . $e->getMessage() . '"} }');
            }
            $fileContent = $this->adapter->getFileContent();
            $result["result"] = $fileContent;
            if (empty(json_encode($result))) {
                $result["result"] = iconv('gb2312', 'utf-8', $fileContent);
            }
            echo json_encode($result);
        }
    }

    /**
    * Save editable file
    *
    * @param string $content Content to be saved
    * @return void
    */
    public function saveContent($content) {
        $contentSize = strlen($content);
        $originSize = $this->fileData["size"];
        if (!FileManage::storageCheck($this->userID, $contentSize)) {
            die('{ "result": { "success": false, "error": "Insufficient storage capacity" } }');
        }
        $this->adapter->saveContent($content);
        FileManage::storageGiveBack($this->userID, $originSize);
        FileManage::storageCheckOut($this->userID, $contentSize);
        Db::name('files')->where('id', $this->fileData["id"])->update(['size' => $contentSize]);
        echo ('{ "result": { "success": true} }');
    }

    /**
    * Preliminary check for file name legality
    *
    * @param string $value File name
    * @return bool Check result
    */
    static function fileNameValidate($value) {
        $validate = new Validate([
            'val'  => 'require|max:250',
            'val' => 'chsDash'
        ]);
        $data = [
            'val'  => $value
        ];
        if (!$validate->check($data)) {
            return false;
        }
        return true;
    }

    /**
    * Handle renaming
    *
    * @param string $fname Original file path
    * @param string $new New file path
    * @param int $uid User ID
    * @param boolean $notEcho Suppress direct output during the process
    * @return mixed
    */
    static function RenameHandler($fname, $new, $uid, $notEcho = false) {
        $folderTmp = $new;
        $originFolder = $fname;
        $new = str_replace("/", "", self::getFileName($new)[0]);
        if (!$notEcho) {
            $new = str_replace(" ", "", $new);
        }
        if (!self::fileNameValidate($new)) {
            if ($notEcho) {
                return '{ "result": { "success": false, "error": "File names can only include numbers, letters, and underscores" } }';
            }
            die('{ "result": { "success": false, "error": "File names can only include numbers, letters, and underscores" } }');
        }
        $path = self::getFileName($fname)[1];
        $fname = self::getFileName($fname)[0];
        $fileRecord = Db::name('files')->where('upload_user', $uid)->where('orign_name', $fname)->where('dir', $path)->find();
        
        if (empty($new)) {
            if ($notEcho) {
                return '{ "result": { "success": false, "error": "File already exists or file name is illegal" } }';
            }
            die('{ "result": { "success": false, "error": "File already exists or file name is illegal" } }');
        }
        
        if (empty($fileRecord)) {
            self::folderRename($originFolder, $folderTmp, $uid, $notEcho);
            die();
        }

        $originSuffix = explode(".", $fileRecord["orign_name"]);
        $newSuffix = explode(".", $new);
        if (end($originSuffix) != end($newSuffix)) {
            if ($notEcho) {
                return '{ "result": { "success": false, "error": "Do not change the file extension" } }';
            }
            die('{ "result": { "success": false, "error": "Do not change the file extension" } }');
        }
        Db::name('files')->where([
            'upload_user' => $uid,
            'dir' => $path,
            'orign_name' => $fname,
        ])->setField('orign_name', $new);
        
        if ($notEcho) {
            return '{ "result": { "success": true} }';
        }
        echo ('{ "result": { "success": true} }');
    }

    /**
    * Handle directory renaming
    *
    * @param string $fname Original directory path
    * @param string $new New directory path
    * @param int $uid User ID
    * @param boolean $notEcho Suppress direct output during the process
    * @return void
    */
    static function folderRename($fname, $new, $uid, $notEcho = false) {
        $newTmp = $new;
        $nerFolderTmp = explode("/", $new);
        $new = array_pop($nerFolderTmp);
        $oldFolderTmp = explode("/", $fname);
        $old = array_pop($oldFolderTmp);
        
        if (!self::fileNameValidate($new)) {
            if ($notEcho) {
                return '{ "result": { "success": false, "error": "Directory names can only include numbers, letters, and underscores" } }';
            }
            die('{ "result": { "success": false, "error": "Directory names can only include numbers, letters, and underscores" } }');
        }
        
        $folderRecord = Db::name('folders')->where('owner', $uid)->where('position_absolute', $fname)->find();
        if (empty($folderRecord)) {
            if ($notEcho) {
                return '{ "result": { "success": false, "error": "Directory does not exist" } }';
            }
            die('{ "result": { "success": false, "error": "Directory does not exist" } }');
        }
        
        $newPositionAbsolute = substr($fname, 0, strrpos($fname, '/')) . "/" . $new;
        Db::name('folders')->where('owner', $uid)->where('position_absolute', $fname)->update([
            'folder_name' => $new,
            'position_absolute' => $newPositionAbsolute,
        ]);

        // Iterate child folders
        $childFolder = Db::name('folders')->where('owner', $uid)->where('position', "like", $fname . "%")->select();
        foreach ($childFolder as $key => $value) {
            $tmpPositionAbsolute = "";
            $tmpPosition = "";
            $pos = strpos($value["position_absolute"], $fname);   
            if ($pos === false) {
                $tmpPositionAbsolute = $value["position_absolute"];   
            }   
            $tmpPositionAbsolute = substr_replace($value["position_absolute"], $newTmp, $pos, strlen($fname));
            $pos = strpos($value["position"], $fname);   
            if ($pos === false) {
                $tmpPosition = $value["position"];   
            }   
            $tmpPosition = substr_replace($value["position"], $newTmp, $pos, strlen($fname));
            Db::name('folders')->where('id', $value["id"])->update([
                'position_absolute' => $tmpPositionAbsolute,
                'position' => $tmpPosition,
            ]);
        }

        // Iterate child files
        $childFiles = Db::name('files')->where('upload_user', $uid)->where('dir', "like", $fname . "%")->select();
        foreach ($childFiles as $key => $value) {
            $tmpPosition = "";
            $pos = strpos($value["dir"], $fname);   
            if ($pos === false) {
                $tmpPosition = $value["dir"];   
            }   
            $tmpPosition = substr_replace($value["dir"], $newTmp, $pos, strlen($fname));
            Db::name('files')->where('id', $value["id"])->update([
                'dir' => $tmpPosition,
            ]);
        }
        if ($notEcho) {
            return '{ "result": { "success": true} }';
        }
        echo ('{ "result": { "success": true} }');
    }

    /**
    * Get file name and parent directory path based on file path
    *
    * @param string $path File path
    * @return array
    */
    static function getFileName($path) {
        $pathSplit = explode("/", $path);
        $fileName = end($pathSplit);
        array_pop($pathSplit);  // Remove the last element
        $path = "";
        
        foreach ($pathSplit as $key => $value) {
            if (!empty($value)) {
                $path .= "/" . $value;
            }
        }
        $path = empty($path) ? "/" : $path;
        return [$fileName, $path];
    }

    /**
    * Handle file preview
    *
    * @param boolean $isAdmin Whether for admin preview
    * @return array Redirect information
    */
    public function PreviewHandler($isAdmin = false) {
        return $this->adapter->Preview($isAdmin);
    }

    /**
    * Get image thumbnail
    *
    * @return array Redirect information
    */
    public function getThumb() {
        return $this->adapter->getThumb();
    }

    /**
    * Handle file download
    *
    * @param boolean $isAdmin Whether it's an admin request
    * @return array File download URL
    */
    public function Download($isAdmin = false) {
        return $this->adapter->Download($isAdmin);
    }

    /**
    * Handle directory deletion
    *
    * @param string $path Directory path
    * @param int $uid     User ID
    * @return void
    */
    static function DirDeleteHandler($path, $uid) {
        global $toBeDeleteDir;
        global $toBeDeleteFile;
        $toBeDeleteDir = [];
        $toBeDeleteFile = [];
        
        foreach ($path as $key => $value) {
            array_push($toBeDeleteDir, $value);
        }
        
        foreach ($path as $key => $value) {
            self::listToBeDelete($value, $uid);
        }
        
        if (!empty($toBeDeleteFile)) {
            self::DeleteHandler($toBeDeleteFile, $uid);
        }
        if (!empty($toBeDeleteDir)) {
            self::deleteDir($toBeDeleteDir, $uid);
        }
    }

    /**
    * List files or directories to be deleted
    *
    * @param string $path Object path
    * @param int $uid     User ID
    * @return void
    */
    static function listToBeDelete($path, $uid) {
        global $toBeDeleteDir;
        global $toBeDeleteFile;
        $fileData = Db::name('files')->where([
            'dir' => $path,
            'upload_user' => $uid,
        ])->select();
        
        foreach ($fileData as $key => $value) {
            array_push($toBeDeleteFile, $path . "/" . $value["orign_name"]);
        }
        
        $dirData = Db::name('folders')->where([
            'position' => $path,
            'owner' => $uid,
        ])->select();
        
        foreach ($dirData as $key => $value) {
            array_push($toBeDeleteDir, $value["position_absolute"]);
            self::listToBeDelete($value["position_absolute"], $uid);
        }
    }

    /**
    * Delete directory
    *
    * @param string $path Directory path
    * @param int $uid     User ID
    * @return void
    */
    static function deleteDir($path, $uid) {
        Db::name('folders')
            ->where("owner", $uid)
            ->where([
                'position_absolute' => ["in", $path],
            ])->delete();
    }

    /**
    * Process delete request
    *
    * @param string $path Path
    * @param int $uid User ID
    * @return array
    */
    static function DeleteHandler($path, $uid) {
        if (empty($path)) {
            return ["result" => ["success" => true, "error" => null]];
        }
        
        foreach ($path as $key => $value) {
            $fileInfo = self::getFileName($value);
            $fileName = $fileInfo[0];
            $filePath = $fileInfo[1];
            $fileNames[$key] = $fileName;
            $filePathes[$key] = $filePath;
        }
        
        $fileData = Db::name('files')->where([
            'orign_name' => ["in", $fileNames],
            'dir' => ["in", $filePathes],
            'upload_user' => $uid,
        ])->select();
        
        $fileListTemp = [];
        $uniquePolicy = self::uniqueArray($fileData);
        
        foreach ($fileData as $key => $value) {
            if (empty($fileListTemp[$value["policy_id"]])) {
                $fileListTemp[$value["policy_id"]] = [];
            }
            array_push($fileListTemp[$value["policy_id"]], $value);
        }
        
        foreach ($fileListTemp as $key => $value) {
            if (in_array($key, $uniquePolicy["qiniuList"])) {
                QiniuAdapter::DeleteFile($value, $uniquePolicy["qiniuPolicyData"][$key][0]);
                self::deleteFileRecord(array_column($value, 'id'), array_sum(array_column($value, 'size')), $value[0]["upload_user"]);
            } else if (in_array($key, $uniquePolicy["localList"])) {
                LocalAdapter::DeleteFile($value, $uniquePolicy["localPolicyData"][$key][0]);
                self::deleteFileRecord(array_column($value, 'id'), array_sum(array_column($value, 'size')), $value[0]["upload_user"]);
            } else if (in_array($key, $uniquePolicy["ossList"])) {
                OssAdapter::DeleteFile($value, $uniquePolicy["ossPolicyData"][$key][0]);
                self::deleteFileRecord(array_column($value, 'id'), array_sum(array_column($value, 'size')), $value[0]["upload_user"]);
            } else if (in_array($key, $uniquePolicy["upyunList"])) {
                UpyunAdapter::DeleteFile($value, $uniquePolicy["upyunPolicyData"][$key][0]);
                self::deleteFileRecord(array_column($value, 'id'), array_sum(array_column($value, 'size')), $value[0]["upload_user"]);
            } else if (in_array($key, $uniquePolicy["s3List"])) {
                S3Adapter::DeleteFile($value, $uniquePolicy["s3PolicyData"][$key][0]);
                self::deleteFileRecord(array_column($value, 'id'), array_sum(array_column($value, 'size')), $value[0]["upload_user"]);
            } else if (in_array($key, $uniquePolicy["remoteList"])) {
                RemoteAdapter::DeleteFile($value, $uniquePolicy["remotePolicyData"][$key][0]);
                self::deleteFileRecord(array_column($value, 'id'), array_sum(array_column($value, 'size')), $value[0]["upload_user"]);
            } else if (in_array($key, $uniquePolicy["onedriveList"])) {
                OnedriveAdapter::DeleteFile($value, $uniquePolicy["onedrivePolicyData"][$key][0]);
                self::deleteFileRecord(array_column($value, 'id'), array_sum(array_column($value, 'size')), $value[0]["upload_user"]);
            }
        }
        return ["result" => ["success" => true, "error" => null]];
    }

    /**
    * Handle moving files
    *
    * @param array $file File path list
    * @param array $dir Directory path list
    * @param string $new New path
    * @param int $uid User ID
    * @return void
    */
    static function MoveHandler($file, $dir, $new, $uid) {
        if (in_array($new, $dir)) {
            die('{ "result": { "success": false, "error": "Cannot move directory to itself" } }');
        }
        if (Db::name('folders')->where('owner', $uid)->where('position_absolute', $new)->find() == null) {
            die('{ "result": { "success": false, "error": "Directory does not exist" } }');
        }
        $moveName = [];
        $movePath = [];
        foreach ($file as $key => $value) {
            $fileInfo = self::getFileName($value);
            $moveName[$key] = $fileInfo[0];
            $movePath[$key] = $fileInfo[1];
        }
        $dirName = [];
        $dirPa = [];
        foreach ($dir as $key => $value) {
            $dirInfo = self::getFileName($value);
            $dirName[$key] = $dirInfo[0];
            $dirPar[$key] = $dirInfo[1];
        }
        $nameCheck = Db::name('files')->where([
            'upload_user' => $uid,
            'dir' => $new,
            'orign_name' => ["in", $moveName],
        ])->find();
        $dirNameCheck = array_merge($dirName, $moveName);
        $dirCheck = Db::name('folders')->where([
            'owner' => $uid,
            'position' => $new,
            'folder_name' => ["in", $dirNameCheck],
        ])->find();
        if ($nameCheck || $dirCheck) {
            die('{ "result": { "success": false, "error": "Filename conflict, please check for duplicates" } }');
        }
        if (!empty($dir)) {
            die('{ "result": { "success": false, "error": "Moving directories is not supported at this time" } }');
        }
        Db::name('files')->where([
            'upload_user' => $uid,
            'dir' => ["in", $movePath],
            'orign_name' => ["in", $moveName],
        ])->setField('dir', $new);
        echo ('{ "result": { "success": true} }');
    }

    /**
    * ToDo Move file
    *
    * @param array $file
    * @param string $path
    * @return void
    */
    static function moveFile($file, $path) {
        // Code to handle moving files
    }

    static function deleteFileRecord($id, $size, $uid) {
        Db::name('files')->where([
            'id' => ["in", $id],
        ])->delete();
        Db::name('shares')
            ->where(['owner' => $uid])
            ->where(['source_type' => "file"])
            ->where(['source_name' => ["in", $id],])
            ->delete();
        Db::name('users')->where([
            'id' => $uid,
        ])->setDec('used_storage', $size);
    }

    /**
    * List files
    *
    * @param string $path Directory path
    * @param int $uid User ID
    * @return array
    */
    static function ListFile($path, $uid) {
        $fileList = Db::name('files')->where('upload_user', $uid)->where('dir', $path)->select();
        $dirList = Db::name('folders')->where('owner', $uid)->where('position', $path)->select();
        $count = 0;
        $fileListData = [];

        foreach ($dirList as $key => $value) {
            $fileListData['result'][$count]['name'] = $value['folder_name'];
            $fileListData['result'][$count]['rights'] = "drwxr-xr-x";
            $fileListData['result'][$count]['size'] = "0";
            $fileListData['result'][$count]['date'] = $value['date'];
            $fileListData['result'][$count]['type'] = 'dir';
            $fileListData['result'][$count]['name2'] = "";
            $fileListData['result'][$count]['id'] = $value['id'];
            $fileListData['result'][$count]['pic'] = "";
            $count++;
        }

        foreach ($fileList as $key => $value) {
            $fileListData['result'][$count]['name'] = $value['orign_name'];
            $fileListData['result'][$count]['rights'] = "drwxr-xr-x";
            $fileListData['result'][$count]['size'] = $value['size'];
            $fileListData['result'][$count]['date'] = $value['upload_date'];
            $fileListData['result'][$count]['type'] = 'file';
            $fileListData['result'][$count]['name2'] = $value["dir"];
            $fileListData['result'][$count]['id'] = $value["id"];
            $fileListData['result'][$count]['pic'] = $value["pic_info"];
            $count++;
        }
        return $fileListData;
    }

    static function listPic($path, $uid, $url = "/File/Preview?") {
        $firstPreview = self::getFileName($path);
        $path = $firstPreview[1];
        $fileList = Db::name('files')
            ->where('upload_user', $uid)
            ->where('dir', $path)
            ->where('pic_info', "<>", " ")
            ->where('pic_info', "<>", "0,0")
            ->where('pic_info', "<>", "null,null")
            ->select();

        $count = 0;
        $fileListData = [];

        foreach ($fileList as $key => $value) {
            if ($value["orign_name"] == $firstPreview[0]) {
                $previewPicInfo = explode(",", $value["pic_info"]);
                $previewSrc = $url . "action=preview&path=" . $path . "/" . $value["orign_name"];
            } else {
                $picInfo = explode(",", $value["pic_info"]);
                $fileListData[$count]['src'] = $url . "action=preview&path=" . $path . "/" . $value["orign_name"];
                $fileListData[$count]['w'] = $picInfo[0];
                $fileListData[$count]['h'] = $picInfo[1];
                $fileListData[$count]['title'] = $value["orign_name"];
                $count++;
            }
        }
        array_unshift($fileListData, array(
            'src' => $previewSrc,
            'w' => $previewPicInfo[0],
            'h' => $previewPicInfo[1],
            'title' => $firstPreview[0],
        ));
        return $fileListData;
    }

    /**
    * Create a folder
    *
    * @param string $dirName Directory name
    * @param string $dirPosition Directory position
    * @param int $uid User ID
    * @return mixed
    */
    static function createFolder($dirName, $dirPosition, $uid) {
        $dirName = str_replace(" ", "", $dirName);
        $dirName = str_replace("/", "", $dirName);
        if (empty($dirName)) {
            return ["result" => ["success" => false, "error" => "Directory name cannot be empty"]];
        }
        if (Db::name('folders')->where('position_absolute', $dirPosition)->where('owner', $uid)->find() == null || 
            Db::name('folders')->where('owner', $uid)->where('position', $dirPosition)->where('folder_name', $dirName)->find() != null || 
            Db::name('files')->where('upload_date', $uid)->where('dir', $dirPosition)->where('pre_name', $dirName)->find() != null) {
            return ["result" => ["success" => false, "error" => "Path does not exist or file already exists"]];
        }

        $sqlData = [
            'folder_name' => $dirName,
            'parent_folder' => Db::name('folders')->where('position_absolute', $dirPosition)->value('id'),
            'position' => $dirPosition,
            'owner' => $uid,
            'date' => date("Y-m-d H:i:s"),
            'position_absolute' => ($dirPosition == "/") ? ($dirPosition . $dirName) : ($dirPosition . "/" . $dirName),
        ];

        if (Db::name('folders')->insert($sqlData)) {
            return ["result" => ["success" => true, "error" => null]];
        }
    }

    static function getTotalStorage($uid) {
        $userData = Db::name('users')->where('id', $uid)->find();
        $basicStorage = Db::name('groups')->where('id', $userData['user_group'])->find();
        $addOnStorage = Db::name('storage_pack')
            ->where('uid', $uid)
            ->where('delay_time', ">", time())
            ->sum('pack_size');
        return $addOnStorage + $basicStorage["max_storage"];
    }

    static function getUsedStorage($uid) {
        $userData = Db::name('users')->where('id', $uid)->find();
        return $userData['used_storage'];
    }

    static function storageCheck($uid, $fsize) {
        $totalStorage = self::getTotalStorage($uid);
        $usedStorage = self::getUsedStorage($uid);
        return ($totalStorage > ($usedStorage + $fsize)) ? true : false;
    }

    static function storageCheckOut($uid, $size) {
        Db::name('users')->where('id', $uid)->setInc('used_storage', $size);
    }

    static function storageGiveBack($uid, $size) {
        Db::name('users')->where('id', $uid)->setDec('used_storage', $size);
    }

    static function addFile($jsonData, $policyData, $uid, $picInfo = " ") {
        $dir = "/" . str_replace(",", "/", $jsonData['path']);
        $fname = $jsonData['fname'];
        if (self::isExist($dir, $fname, $uid)) {
            return [false, "File already exists"];
        }
        $folderBelong = Db::name('folders')->where('owner', $uid)->where('position_absolute', $dir)->find();
        if ($folderBelong == null) {
            return [false, "Directory does not exist"];
        }
        $sqlData = [
            'orign_name' => $jsonData['fname'],
            'pre_name' => $jsonData['objname'],
            'upload_user' => $uid,
            'size' => $jsonData['fsize'],
            'upload_date' => date("Y-m-d H:i:s"),
            'parent_folder' => $folderBelong['id'],
            'policy_id' => $policyData['id'],
            'dir' => $dir,
            'pic_info' => $picInfo,
        ];
        if (Db::name('files')->insert($sqlData)) {
            return [true, "Upload successful"];
        }
    }

    static function isExist($dir, $fname, $uid) {
        return Db::name('files')->where('upload_user', $uid)->where('dir', $dir)->where('orign_name', $fname)->find() != null;
    }

    static function deleteFile($fname, $policy) {
        switch ($policy['policy_type']) {
            case 'qiniu':
                return QiniuAdapter::deleteSingle($fname, $policy);
                break;
            case 'oss':
                return OssAdapter::deleteOssFile($fname, $policy);
                break;
            case 'upyun':
                return UpyunAdapter::deleteUpyunFile($fname, $policy);
                break;
            case 's3':
                return S3Adapter::deleteS3File($fname, $policy);
                break;
            default:
                // Handle unknown policy type
                break;
        }
    }

    static function uniqueArray($data = array()) {
        $tempList = [];
        $qiniuList = [];
        $qiniuPolicyData = [];
        $localList = [];
        $localPolicyData = [];
        $ossList = [];
        $ossPolicyData = [];
        $upyunList = [];
        $upyunPolicyData = [];
        $s3List = [];
        $s3PolicyData = [];
        $remoteList = [];
        $remotePolicyData = [];
        $onedriveList = [];
        $onedrivePolicyData = [];

        foreach ($data as $key => $value) {
            if (!in_array($value['policy_id'], $tempList)) {
                array_push($tempList, $value['policy_id']);
                $policyTempData = Db::name('policy')->where('id', $value['policy_id'])->find();
                switch ($policyTempData["policy_type"]) {
                    case 'qiniu':
                        array_push($qiniuList, $value['policy_id']);
                        if (empty($qiniuPolicyData[$value['policy_id']])) {
                            $qiniuPolicyData[$value['policy_id']] = [];
                        }
                        array_push($qiniuPolicyData[$value['policy_id']], $policyTempData);
                        break;
                    case 'local':
                        array_push($localList, $value['policy_id']);
                        if (empty($localPolicyData[$value['policy_id']])) {
                            $localPolicyData[$value['policy_id']] = [];
                        }
                        array_push($localPolicyData[$value['policy_id']], $policyTempData);
                        break;
                    case 'oss':
                        array_push($ossList, $value['policy_id']);
                        if (empty($ossPolicyData[$value['policy_id']])) {
                            $ossPolicyData[$value['policy_id']] = [];
                        }
                        array_push($ossPolicyData[$value['policy_id']], $policyTempData);
                        break;
                    case 'upyun':
                        array_push($upyunList, $value['policy_id']);
                        if (empty($upyunPolicyData[$value['policy_id']])) {
                            $upyunPolicyData[$value['policy_id']] = [];
                        }
                        array_push($upyunPolicyData[$value['policy_id']], $policyTempData);
                        break;
                    case 's3':
                        array_push($s3List, $value['policy_id']);
                        if (empty($s3PolicyData[$value['policy_id']])) {
                            $s3PolicyData[$value['policy_id']] = [];
                        }
                        array_push($s3PolicyData[$value['policy_id']], $policyTempData);
                        break;
                    case 'remote':
                        array_push($remoteList, $value['policy_id']);
                        if (empty($remotePolicyData[$value['policy_id']])) {
                            $remotePolicyData[$value['policy_id']] = [];
                        }
                        array_push($remotePolicyData[$value['policy_id']], $policyTempData);
                        break;
                    case 'onedrive':
                        array_push($onedriveList, $value['policy_id']);
                        if (empty($onedrivePolicyData[$value['policy_id']])) {
                            $onedrivePolicyData[$value['policy_id']] = [];
                        }
                        array_push($onedrivePolicyData[$value['policy_id']], $policyTempData);
                        break;
                    default:
                        // Handle unknown policy type
                        break;
                }
            }
        }
        $returnValue = array(
            'policyId' => $tempList,
            'qiniuList' => $qiniuList,
            'qiniuPolicyData' => $qiniuPolicyData,
            'localList' => $localList,
            'localPolicyData' => $localPolicyData,
            'ossList' => $ossList,
            'ossPolicyData' => $ossPolicyData,
            'upyunList' => $upyunList,
            'upyunPolicyData' => $upyunPolicyData,
            's3List' => $s3List,
            's3PolicyData' => $s3PolicyData,
            'remoteList' => $remoteList,
            'remotePolicyData' => $remotePolicyData,
            'onedriveList' => $onedriveList,
            'onedrivePolicyData' => $onedrivePolicyData,
        );
        return $returnValue;
    }

    public function signTmpUrl() {
        return $this->adapter->signTmpUrl()[1];
    }
}
?>