<?php
namespace app\index\model;

use think\Model;
use think\Db;
use \think\Session;
use \PHPGangsta_GoogleAuthenticator;
use \Endroid\QrCode\QrCode;
use \app\index\model\Option;

class TwoFactor extends Model {
    public $ga;
    public $secretKey;
    public $checkResult;

    public function __construct() {
        $this->ga = new PHPGangsta_GoogleAuthenticator();
    }

    /**
    * Render the QR code for Google Authenticator
    *
    * @return void
    */
    public function qrcodeRender() {
        ob_end_clean();
        $this->secretKey = $this->ga->createSecret();
        session("two_factor_enable", $this->secretKey);
        $qrCode = new QrCode(urldecode(str_replace("https://chart.googleapis.com/chart?chs=200x200&chld=M|0&cht=qr&chl=", "", $this->ga->getQRCodeGoogleUrl(Option::getValue("siteName"), $this->secretKey))));
        $qrCode->setSize(165);
        $qrCode->setMargin(0);
        header('Content-Type: ' . $qrCode->getContentType());
        echo $qrCode->writeString();
    }

    /**
    * Confirm the provided code against the secret key
    *
    * @param string $key The secret key
    * @param string $code The code input by the user
    * @return array Result of the confirmation
    */
    public function confirmCode($key, $code) {
        $this->secretKey = $key;
        if (empty($code)) {
            return [0, "Verification code cannot be empty"];
        }
        if (empty($key)) {
            return [0, "QR code has expired, please refresh the page and scan again"];
        }
        $this->checkResult = $this->ga->verifyCode($key, $code, 2);
        if ($this->checkResult) {
            return [1, "Verification successful"];
        } else {
            return [0, "Verification code incorrect"];
        }
    }

    /**
    * Bind the user with the provided UID to two-factor authentication
    *
    * @param int $uid User ID
    * @return void
    */
    public function bindUser($uid) {
        Db::name("users")->where("id", $uid)->update(["two_step" => $this->secretKey]);
    }
}
?>