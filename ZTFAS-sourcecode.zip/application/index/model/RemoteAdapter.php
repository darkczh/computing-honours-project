<?php
namespace app\index\model;

use think\Model;
use think\Db;
use \app\index\model\Option;

/**
* Remote policy file management adapter
*/
class RemoteAdapter extends Model {
    private $fileModel;
    private $policyModel;
    private $userModel;

    public function __construct($file, $policy, $user) {
        $this->fileModel = $file;
        $this->policyModel = $policy;
        $this->userModel = $user;
    }

    /**
    * Get the content of the text file
    *
    * @return string File content
    */
    public function getFileContent() {
        return file_get_contents($this->Preview()[1]);
    }

    /**
    * Sign the file preview URL
    *
    * @return void
    */
    public function Preview() {
        $remote = new Remote($this->policyModel);
        return [1, $remote->preview($this->fileModel["pre_name"])];
    }

    /**
    * Save file content
    *
    * @param string $content File content
    * @return bool
    */
    public function saveContent($content) {
        $remote = new Remote($this->policyModel);
        $remote->updateContent($this->fileModel["pre_name"], $content);
    }

    /**
    * Get thumbnail address
    *
    * @return string Thumbnail address
    */
    public function getThumb() {
        $remote = new Remote($this->policyModel);
        return [1, $remote->thumb($this->fileModel["pre_name"], explode(",", $this->fileModel["pic_info"]))];
    }

    /**
    * Delete specified files under a certain policy
    *
    * @param array $fileList   Database records of files to be deleted
    * @param array $policyData Upload policy information for the files to be deleted
    * @return void
    */
    static function deleteFile($fileList, $policyData) {
        $remoteObj = new Remote($policyData);
        $remoteObj->remove(array_column($fileList, 'pre_name'));
    }

    /**
    * Generate file download URL
    *
    * @return array
    */
    public function Download() {
        $remote = new Remote($this->policyModel);
        return [1, $remote->download($this->fileModel["pre_name"], $this->fileModel["orign_name"])];
    }

    /**
    * Sign a temporary URL for Office preview
    *
    * @return array
    */
    public function signTmpUrl() {
        return $this->Preview();
    }
}
?>