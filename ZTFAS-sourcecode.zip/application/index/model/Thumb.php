<?php
namespace app\index\model;

use think\Model;

class Thumb extends Model {  
    private $file;    // Image path  
    private $width;   // Image width  
    private $height;  // Image height  
    private $img_type;    // Image type  
    private $img;     // Resource handle for the original image  
    private $new;     // Resource handle for the new image  

    // Constructor method, initializes the image object  
    public function __construct($_file) {  
        $this->file = $_file;  
        list($this->width, $this->height, $this->img_type) = getimagesize($this->file);  
        $this->img = $this->getFromImg($this->file, $this->img_type);  
    }  

    // Thumbnail generation (fixed container dimensions, image scale proportionally, extended to fill, cropped) [Fixed size, no distortion, no deformation]  
    public function thumb($new_width = 0, $new_height = 0) {  
        if (empty($new_width) && empty($new_height)) {  
            $new_width = $this->width;  
            $new_height = $this->height;  
        }  
        if (!is_numeric($new_width) || !is_numeric($new_height)) {  
            $new_width = $this->width;  
            $new_height = $this->height;  
        }  

        // Create a container  
        $_n_w = $new_width;  
        $_n_h = $new_height;  
        // Create cropping points  
        $_cut_width = 0;  
        $_cut_height = 0;  

        if ($this->width < $this->height) {  
            $new_width = ($new_height / $this->height) * $this->width;  
        } else {  
            $new_height = ($new_width / $this->width) * $this->height;  
        }  
        
        if ($new_width < $_n_w) { // If the new width is less than the new container width  
            $r = $_n_w / $new_width; // Calculate the aspect ratio  
            $new_width *= $r; // Adjust the expanded width  
            $new_height *= $r; // Adjust the expanded height  
            $_cut_height = ($new_height - $_n_h) / 2; // Calculate the cropping height  
        }  
        
        if ($new_height < $_n_h) { // If the new height is less than the container height  
            $r = $_n_h / $new_height; // Calculate the aspect ratio  
            $new_width *= $r; // Adjust the expanded width  
            $new_height *= $r; // Adjust the expanded height  
            $_cut_width = ($new_width - $_n_w) / 2; // Calculate the cropping width  
        }  
        
        $this->new = imagecreatetruecolor($_n_w, $_n_h);  
        imagecopyresampled($this->new, $this->img, 0, 0, $_cut_width, $_cut_height, $new_width, $new_height, $this->width, $this->height);  
    }  

    // Load image of various types and return the image resource handle  
    private function getFromImg($_file, $_type) {  
        switch ($_type) {  
            case 1:  
                $img = imagecreatefromgif($_file);  
                break;  
            case 2:  
                $img = imagecreatefromjpeg($_file);  
                break;  
            case 3:   
                $img = imagecreatefrompng($_file);  
                break;  
            default:  
                $img = '';  
        }  
        return $img;  
    }  

    // Output the image  
    public function out($name) {  
        imagepng($this->new, $name); // The second parameter is the name of the new generated image  
        imagedestroy($this->img);  
        imagedestroy($this->new);  
    }  
}  
?>