<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:80:"/www/wwwroot/caigou-netdisk.mcbar.cc/application/index/view/profile/profile.html";i:1739205382;s:78:"/www/wwwroot/caigou-netdisk.mcbar.cc/application/index/view/header_public.html";i:1536836016;s:78:"/www/wwwroot/caigou-netdisk.mcbar.cc/application/index/view/navbar_public.html";i:1739202756;}*/ ?>
<html lang="zh-cn" data-ng-app="FileManagerApp">
	<head>
		<meta name="viewport" content="initial-scale=1.0, user-scalable=no">
		<meta charset="utf-8">
		<meta name="theme-color" content="#4e64d9"/>
		<title>Profile - <?php echo $options['siteName']; ?></title>
		<!-- third party -->
		<script src="/static/js/jquery.min.js"></script>
		<link rel="stylesheet" href="/static/css/bootstrap.min.css" />
		<link rel="stylesheet" href="/static/css/material.css" />
		<link rel="stylesheet" href="/static/css/animate.css" />
		<script src="/static/js/material.js"></script>
		<script src="/static/js/bootstrap.min.js"></script>
		<link rel="stylesheet" href="/static/css/font-awesome.min.css">
		<!-- /third party -->
		<!-- Comment if you need to use raw source code -->
		<link href="/static/css/toastr.min.css" rel="stylesheet">
		<script type="text/javascript" src="/static/js/toastr.min.js"></script>
		<!-- /Comment if you need to use raw source code -->
		
<link rel="stylesheet" href="/static/css/profile.css" />
</head>
<body data-ma-header="teal">
<nav class="navbar navbar-inverse" >
    <div class="container-fluid">
        <div class="container" >
            <div class="navbar-header">
    <div>
        <a class="navbar-brand waves-light" href="/">
            <!-- Brand logo or text can go here -->
        </a>
    </div>
    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
    </button>
</div>

<!-- Collect the nav links, forms, and other content for toggling -->
<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
    <ul class="nav navbar-nav navbar-right">
        <?php if($loginStatus == '1'): ?>
        <li class="dropdown">
            <a href="#" class="dropdown-toggle avatar-a waves-light" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                <img src="/Member/Avatar/<?php echo $userData['id']; ?>/s" class="img-circle avatar-s"> 
                <?php echo $userData['user_nick']; ?> <span class="caret"></span>
            </a>
            <ul class="dropdown-menu">
                <li><a href="/Home">My Files</a></li>
                <li><a href="/Profile/<?php echo $userData['id']; ?>">Profile</a></li>
                <li><a href="/Member/Setting">Settings</a></li>
                <li role="separator" class="divider"></li>
                <li><a href="/Member/LogOut">Logout</a></li>
            </ul>
        </li>
        <?php else: ?>
        <li>
            <a href="/Login" class="dropdown-toggle waves-light" role="button" aria-haspopup="true" aria-expanded="false">
                <i class="fa fa-user mr-1"></i> Login/Register 
            </a>
        </li>
        <?php endif; ?>
    </ul>
</div><!-- /.navbar-collapse -->
            <div class="header-panel shadow-z-2">
                <div class="container-fluid">
                    <div class="row">
                        
                    </div>
                </div>
            </div>
            <div class="container main-h">
                <div class="col-md-3">
                    <div class="card type--profile">
                        <header class="card-heading card-background" id="card_img_02">
                            <img src="/Member/Avatar/<?php echo $userInfo['id']; ?>/l" alt="" class="img-circle">
                            <ul class="card-actions icons  right-top">
                                <li class="dropdown" style="display: none;">
                                    <a href="javascript:void(0)" data-toggle="dropdown" aria-expanded="false">
                                        <i class="zmdi zmdi-more-vert text-white"></i>
                                    </a>
                                    <ul class="dropdown-menu dropdown-menu-right">
                                        <li>
                                            <a href="javascript:void(0)">Option One</a>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0)">Option Two</a>
                                        </li>
                                        <li>
                                            <a href="javascript:void(0)">Option Three</a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </header>
                        <div class="card-body">
                            <h3 class="name"><?php echo htmlspecialchars($userInfo['user_nick'],ENT_NOQUOTES); ?></h3>
                            <span class="title span-fix"><span class="label span-fix label-<?php echo $groupData['color']; ?>"><?php echo $groupData['group_name']; ?></span></span>
                            
                        </div>
                        <footer class="card-footer border-top">
                            <div class="row row p-t-10 p-b-10">
                                <div class="col-xs-4"><span class="count"><?php echo $shareCount; ?></span><span>Public Share</span></div>
                                <div class="col-xs-4"><span class="count"><?php echo $regDays; ?></span><span>Registered Days</span></div>
                                <div class="col-xs-4"><span class="count"><?php echo $userInfo['id']; ?></span><span>User No.</span></div>
                            </div>
                        </footer>
                    </div>
                </div>
                <div class="col-md-9">
                    <div class="jumbotron">
                        <div class="card_botom">
                            <div class="row bottom-width">
                                <ul class="nav nav-tabs" >
                                    <li id="all"><a href="?page=1"  aria-expanded="true">All Shares<div class="ripple-container"></div></a></li>
                                    <li id="hot"><a href="?type=hot"  aria-expanded="false">Hot Shares<div class="ripple-container"></div></a></li>
                                    
                                </ul>
                                <div id="myTabContent" class="tab-content">
                                    <div class="tab-pane fade active in">
                                        <div class="panel panel-default">
                                            <div class="panel-body" >
                                             
                                                <div class="table-responsive">
                                                    <table class="table table-striped">
                                                        <thead>
                                                            <tr>
                                                                <th width="50%">Name </th>
                                                                <th class="cent">Date</th>
                                                                <th class="cent">Downloads</th>
                                                                <th class="cent">Views</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody><?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$shares): $mod = ($i % 2 );++$i;?>
                                                        <tr>
                                                                <td ><?php switch($shares['source_type']): case "file": ?><i class="fa fa-file" aria-hidden="true"></i> <?php break; case "dir": ?><i class="fa fa-folder-open blue" aria-hidden="true"></i> <?php break; endswitch; ?> <a href="/s/<?php echo $shares['share_key']; ?>" class="fname" target="_blank"><?php echo htmlspecialchars($shares['fileData'],ENT_NOQUOTES); ?></a></td>
                                                             <td class="cent"><?php echo $shares['share_time']; ?></td>
                                                             <td align="center"><?php echo $shares['download_num']; ?></td>
                                                             <td align="center"><?php echo $shares['view_num']; ?></td>
                                                            </tr>

                                                            <?php endforeach; endif; else: echo "" ;endif; ?>
                                                        </tbody>
                                                    </table>

                                                </div>
                                                <div class="navi">
                                                 <?php if($type == 'hot'): else: ?>
                                                <?php echo $listOrigin->render(); endif; ?>
                                                </div>
                                            </div></div></div></div>
                                        </div>
                                    </div>
                                </div></div>
                            </div>
                        </div>
                    </body>
                    <script type="text/javascript">
                    </script>
                    <script src="/static/js/material.js"></script>
                    <script src="/static/js/profile.js"> </script>
                    <?php echo $options['js_code']; ?>
                    
