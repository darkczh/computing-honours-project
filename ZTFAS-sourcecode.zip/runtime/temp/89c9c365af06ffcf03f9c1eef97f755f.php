<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:80:"/www/wwwroot/caigou-netdisk.mcbar.cc/application/index/view/admin/add_group.html";i:1739195168;s:77:"/www/wwwroot/caigou-netdisk.mcbar.cc/application/index/view/header_admin.html";i:1739209039;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Add User Group - <?php echo $options['siteName']; ?></title>
  <!-- Bootstrap core CSS-->
  <link href="/static/css/bootstrap4/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="/static/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="/static/css/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <link href="/static/css/toastr.min.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="/static/css/sb-admin.css" rel="stylesheet">
</head>
<body class="<?php echo $options['admin_color_body']; ?>" id="page-top">
  <!-- Navigation -->
  <nav class="<?php echo $options['admin_color_nav']; ?>" id="mainNav">
    <a class="navbar-brand" href="index.html">ZTFAS Admin</a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
          <a class="nav-link" href="/Admin">
            <i class="fa fa-fw fa-dashboard"></i>
            <span class="nav-link-text">Dashboard</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Settings">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseComponents" data-parent="#exampleAccordion">
            <i class="fa fa-fw fa-wrench"></i>
            <span class="nav-link-text">Settings</span>
          </a>
          <ul class="sidenav-second-level collapse" id="collapseComponents">
            <li>
              <a href="/Admin/Setting">Basic Settings</a>
            </li>
            <li>
              <a href="/Admin/SettingReg">Registration Access</a>
            </li>
            <li>
              <a href="/Admin/SettingMail">Email Sending</a>
            </li>
            <li>
              <a href="/Admin/Config">Configuration File</a>
            </li>
            <li>
              <a href="/Admin/SettingOther">Miscellaneous</a>
            </li>
          </ul>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Templates">
          <a class="nav-link" href="/Admin/Theme">
            <i class="fa fa-fw fa-paint-brush"></i>
            <span class="nav-link-text">Templates</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Files">
          <a class="nav-link" href="/Admin/Files">
            <i class="fa fa-fw fa-folder"></i>
            <span class="nav-link-text">Files</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Shares">
          <a class="nav-link" href="/Admin/Shares">
            <i class="fa fa-fw fa-send"></i>
            <span class="nav-link-text">Shares</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Remote Download">
          <a class="nav-link" href="/Admin/RemoteDownload">
            <i class="fa fa-fw fa-cloud-download"></i>
            <span class="nav-link-text">Remote Download</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Users">
          <a class="nav-link" href="/Admin/Users" data-parent="#user">
            <i class="fa fa-fw fa-user"></i>
            <span class="nav-link-text">Users</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="User Groups">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#group" data-parent="#group">
            <i class="fa fa-fw fa-users"></i>
            <span class="nav-link-text">User Groups</span>
          </a>
          <ul class="sidenav-second-level collapse" id="group">
            <li>
              <a href="/Admin/GroupList">Manage</a>
            </li>
            <li>
              <a href="/Admin/GroupAdd">Add</a>
            </li>
          </ul>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Upload Policies">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#policy" data-parent="#policy">
            <i class="fa fa-fw fa-upload"></i>
            <span class="nav-link-text">Upload Policies</span>
          </a>
          <ul class="sidenav-second-level collapse" id="policy">
            <li>
              <a href="/Admin/PolicyList">Manage</a>
            </li>
            <li>
              <a href="/Admin/PolicyAdd">Add</a>
            </li>
          </ul>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Others">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#else" data-parent="#else">
            <i class="fa fa-fw fa-ellipsis-h"></i>
            <span class="nav-link-text">Others</span>
          </a>
          <ul class="sidenav-second-level collapse" id="else">
            <li>
              <a href="/Admin/Queue">Task Queue</a>
            </li>
            <li>
              <a href="/Admin/Cron">Scheduled Tasks</a>
            </li>
            <li>
              <a href="/Admin/About">About</a>
            </li>
          </ul>
        </li>
      </ul>
      <ul class="navbar-nav sidenav-toggler">
        <li class="nav-item">
          <a class="nav-link text-center" id="sidenavToggler">
            <i class="fa fa-fw fa-angle-left"></i>
          </a>
        </li>
      </ul>
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link" href="javascript:void(0)" id="toggleNavColor">
            <i class="fa fa-fw fa-toggle-on" aria-hidden="true"></i> Switch Color Scheme
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/">
            <i class="fa fa-fw fa-home"></i> Return to Homepage
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" data-toggle="modal" data-target="#exampleModal">
            <i class="fa fa-fw fa-sign-out"></i> Logout
          </a>
        </li>
      </ul>
    </div>
  </nav>
  
<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="/Admin">Admin Panel</a>
            </li>
            <li class="breadcrumb-item active">User Groups</li>
            <li class="breadcrumb-item active">Add User Group</li>
        </ol>
        <!-- Area Chart Example-->
        <div class="row">
            <div class="col-12">
                <h2>Add User Group</h2>
                <br>
                <form id="addGroup">
                    <div class="row form-setting">
                        <div class="col-md-1 form-label">
                            <label for="colFormLabelSm" class="col-form-label col-form-label-sm">User Group Name</label>
                        </div>
                        <div class="col-md-4">
                            <input type="text" class="form-control" name="group_name" required>
                        </div>
                        <div class="col-md-4 option-des"> Name of the user group</div>
                    </div>
                    <div class="row form-setting">
                        <div class="col-md-1 form-label">
                            <label for="colFormLabelSm" class="col-form-label col-form-label-sm">Upload Policy</label>
                        </div>
                        <div class="col-md-4">
                            <select name="policy_name" required class="form-control">
                                <?php if(is_array($policy) || $policy instanceof \think\Collection || $policy instanceof \think\Paginator): $i = 0; $__LIST__ = $policy;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$p): $mod = ($i % 2 );++$i;?>
                                <option value="<?php echo $p['id']; ?>"><?php echo $p['policy_name']; ?></option>
                                <?php endforeach; endif; else: echo "" ;endif; ?>
                            </select>
                        </div>
                        <div class="col-md-4 option-des"> Bind an upload policy to this user group</div>
                    </div>
                    <div class="row form-setting">
                        <div class="col-md-1 form-label">
                            <label for="colFormLabelSm" class="col-form-label col-form-label-sm">Initial Storage Capacity</label>
                        </div>
                        <div class="col-md-4 input-group mb-3">
                            <input type="number" class="form-control" name="max_storage" spellcheck="false" min="0" value="10" required>
                            <div class="input-group-append">
                                <span class="input-group-text" id="basic-addon2">
                                    <select name="sizeTimes" class="selectIn">
                                        <option value="1">B</option>
                                        <option value="1024">KB</option>
                                        <option value="1048576" selected>MB</option>
                                        <option value="1073741824">GB</option>
                                    </select>
                                </span>
                            </div>
                        </div>
                        <div class="col-md-4 option-des"> This is the initial maximum available capacity for the user group</div>
                    </div>
                    <div class="row form-setting">
                        <div class="col-md-1 form-label">
                            <label for="colFormLabelSm" class="col-form-label col-form-label-sm">Download Speed Limit</label>
                        </div>
                        <div class="col-md-4 input-group mb-3">
                            <input type="number" class="form-control" name="speed" spellcheck="false" min="0" placeholder="Leave blank for no speed limit, 0 to prohibit downloads">
                            <div class="input-group-append">
                                <span class="input-group-text" id="basic-addon2">
                                    Kb/s
                                </span>
                            </div>
                        </div>
                        <div class="col-md-4 option-des"> Limit the download speed of files uploaded by users in this group. <strong>This setting is only applicable to local upload solutions</strong></div>
                    </div>
                    <div class="row form-setting">
                        <div class="col-md-1 form-label ">
                            <label for="colFormLabelSm" class="col-form-label col-form-label-sm">Allow Resuming and Multi-threaded Downloads</label>
                        </div>
                        <div class="col-md-4">
                            <input class="" type="radio" name="range_transfer" value="1" id="allow_range_1" checked>
                            <label class="" for="allow_range_1">Allow</label>
                            &nbsp;&nbsp;&nbsp;
                            <input class="" type="radio" name="range_transfer" id="allow_range_0" value="0">
                            <label class="" for="allow_range_0">Prohibit</label>
                        </div>
                        <div class="col-md-4 option-des"> Whether to allow resuming and multi-threaded downloads. Disabling this will not support dragging playback for preview videos. <strong>This setting is only applicable to local upload solutions</strong></div>
                    </div>
                    <div class="row form-setting">
                        <div class="col-md-1 form-label ">
                            <label for="colFormLabelSm" class="col-form-label col-form-label-sm">Enable File Sharing</label>
                        </div>
                        <div class="col-md-4">
                            <input class="" type="radio" name="allow_share" value="1" id="allow_share_1" checked>
                            <label class="" for="allow_share_1">Allow</label>
                            &nbsp;&nbsp;&nbsp;
                            <input class="" type="radio" name="allow_share" id="allow_share_0" value="0">
                            <label class="" for="allow_share_0">Prohibit</label>
                        </div>
                        <div class="col-md-4 option-des"> Whether to allow users to create file sharing links</div>
                    </div>
                    <div class="row form-setting">
                        <div class="col-md-1 form-label ">
                            <label for="colFormLabelSm" class="col-form-label col-form-label-sm">WebDAV Support</label>
                        </div>
                        <div class="col-md-4">
                            <input class="" type="radio" name="webdav" value="1" id="webdav1" checked>
                            <label class="" for="webdav1">Allow</label>
                            &nbsp;&nbsp;&nbsp;
                            <input class="" type="radio" name="webdav" id="webdav0" value="0">
                            <label class="" for="webdav0">Prohibit</label>
                        </div>
                        <div class="col-md-4 option-des"> Whether to allow users to synchronize files using the WebDAV protocol. Currently, this feature only supports local upload solutions</div>
                    </div>
                    <div class="row form-setting">
                        <div class="col-md-1 form-label ">
                            <label for="colFormLabelSm" class="col-form-label col-form-label-sm">Offline Download</label>
                        </div>
                        <div class="col-md-4">
                            <input class="" type="radio" name="aria2" value="1" id="webdav1">
                            <label class="" for="webdav1">Allow</label>
                            &nbsp;&nbsp;&nbsp;
                            <input class="" type="radio" name="aria2" id="webdav0" value="0" checked>
                            <label class="" for="webdav0">Prohibit</label>
                        </div>
                        <div class="col-md-4 option-des"> Whether to allow users to use offline downloads. This feature only supports local storage policies, and needs to be set in the offline download management page</div>
                    </div>
                    <div class="row form-setting">
                        <div class="col-md-1 form-label ">
                            <label for="colFormLabelSm" class="col-form-label col-form-label-sm">User Group Color Flag</label>
                        </div>
                        <div class="col-md-4">
                            <input class="" type="radio" name="color" value="default" id="default" checked>
                            <label class="" for="default"><span class="badge badge-primary">Blue</span></label>
                            &nbsp;&nbsp;&nbsp;
                            <input class="" type="radio" name="color" value="primary" id="primary">
                            <label class="" for="primary"><span class="badge badge-secondary">Gray</span></label>
                            &nbsp;&nbsp;&nbsp;
                            <input class="" type="radio" name="color" value="success" id="success">
                            <label class="" for="success"><span class="badge badge-success">Green</span></label>
                            &nbsp;&nbsp;&nbsp;
                            <input class="" type="radio" name="color" value="danger" id="danger">
                            <label class="" for="danger"><span class="badge badge-danger">Red</span></label>
                            <br>
                            <input class="" type="radio" name="color" value="warning" id="warning">
                            <label class="" for="warning"><span class="badge badge-warning">Yellow</span></label>
                            &nbsp;&nbsp;&nbsp;
                            <input class="" type="radio" name="color" value="info" id="info">
                            <label class="" for="info"><span class="badge badge-info">Light Blue</span></label>
                            &nbsp;&nbsp;&nbsp;
                        </div>
                        <div class="col-md-4 option-des"> Badge color displayed for user groups on the user's personal homepage</div>
                    </div>
                    <div class="row form-setting">
                        <div class="col-md-1 form-label ">
                        </div>
                        <div class="col-md-4">
                            <button type="submit" class="btn btn-primary" id="saveGroup">Add</button>
                        </div>
                        <div class="col-md-4 option-des"> </div>
                        <br><br><br>
                    </div>
                </form>
            </div>
        </div>
        <!-- Example DataTables Card-->
    </div>
    <!-- /.container-fluid-->
</div>
<!-- /.content-wrapper-->

  <footer class="sticky-footer">
    <div class="container">
      <div class="text-center">
        <small>Copyright © ZTFAS by Zhanghao Cai;</small>
      </div>
    </div>
  </footer>
  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fa fa-angle-up"></i>
  </a>
  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Confirmation</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Click the “Logout” button to exit the current account.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="/Member/LogOut">Logout</a>
        </div>
      </div>
    </div>
  </div>
  <script src="/static/js/jquery.min.js"></script>
  <script src="/static/js/bootstrap4/bootstrap.bundle.min.js"></script>
  <!-- Core plugin JavaScript -->
  <script src="/static/js/chart.js/Chart.min.js"></script>
  <!-- Custom scripts for all pages -->
  <script src="/static/js/sb-admin.min.js"></script>
  <script type="text/javascript" src="/static/js/toastr.min.js"></script>
  
<script src="/static/js/admin/add_group.js"></script>
<script type="text/javascript">
</script>

</body>
</html>