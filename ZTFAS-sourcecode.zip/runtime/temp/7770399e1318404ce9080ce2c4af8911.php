<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:75:"/www/wwwroot/caigou-netdisk.mcbar.cc/application/index/view/admin/task.html";i:1739195052;s:77:"/www/wwwroot/caigou-netdisk.mcbar.cc/application/index/view/header_admin.html";i:1739202492;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Task Queue - <?php echo $options['siteName']; ?></title>
  <!-- Bootstrap core CSS-->
  <link href="/static/css/bootstrap4/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="/static/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="/static/css/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <link href="/static/css/toastr.min.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="/static/css/sb-admin.css" rel="stylesheet">
</head>
<body class="<?php echo $options['admin_color_body']; ?>" id="page-top">
  <!-- Navigation -->
  <nav class="<?php echo $options['admin_color_nav']; ?>" id="mainNav">
    <a class="navbar-brand" href="index.html">Cloudreve</a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
          <a class="nav-link" href="/Admin">
            <i class="fa fa-fw fa-dashboard"></i>
            <span class="nav-link-text">Dashboard</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Settings">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseComponents" data-parent="#exampleAccordion">
            <i class="fa fa-fw fa-wrench"></i>
            <span class="nav-link-text">Settings</span>
          </a>
          <ul class="sidenav-second-level collapse" id="collapseComponents">
            <li>
              <a href="/Admin/Setting">Basic Settings</a>
            </li>
            <li>
              <a href="/Admin/SettingReg">Registration Access</a>
            </li>
            <li>
              <a href="/Admin/SettingMail">Email Sending</a>
            </li>
            <li>
              <a href="/Admin/Config">Configuration File</a>
            </li>
            <li>
              <a href="/Admin/SettingOther">Miscellaneous</a>
            </li>
          </ul>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Templates">
          <a class="nav-link" href="/Admin/Theme">
            <i class="fa fa-fw fa-paint-brush"></i>
            <span class="nav-link-text">Templates</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Files">
          <a class="nav-link" href="/Admin/Files">
            <i class="fa fa-fw fa-folder"></i>
            <span class="nav-link-text">Files</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Shares">
          <a class="nav-link" href="/Admin/Shares">
            <i class="fa fa-fw fa-send"></i>
            <span class="nav-link-text">Shares</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Remote Download">
          <a class="nav-link" href="/Admin/RemoteDownload">
            <i class="fa fa-fw fa-cloud-download"></i>
            <span class="nav-link-text">Remote Download</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Users">
          <a class="nav-link" href="/Admin/Users" data-parent="#user">
            <i class="fa fa-fw fa-user"></i>
            <span class="nav-link-text">Users</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="User Groups">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#group" data-parent="#group">
            <i class="fa fa-fw fa-users"></i>
            <span class="nav-link-text">User Groups</span>
          </a>
          <ul class="sidenav-second-level collapse" id="group">
            <li>
              <a href="/Admin/GroupList">Manage</a>
            </li>
            <li>
              <a href="/Admin/GroupAdd">Add</a>
            </li>
          </ul>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Upload Policies">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#policy" data-parent="#policy">
            <i class="fa fa-fw fa-upload"></i>
            <span class="nav-link-text">Upload Policies</span>
          </a>
          <ul class="sidenav-second-level collapse" id="policy">
            <li>
              <a href="/Admin/PolicyList">Manage</a>
            </li>
            <li>
              <a href="/Admin/PolicyAdd">Add</a>
            </li>
          </ul>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Others">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#else" data-parent="#else">
            <i class="fa fa-fw fa-ellipsis-h"></i>
            <span class="nav-link-text">Others</span>
          </a>
          <ul class="sidenav-second-level collapse" id="else">
            <li>
              <a href="/Admin/Queue">Task Queue</a>
            </li>
            <li>
              <a href="/Admin/Cron">Scheduled Tasks</a>
            </li>
            <li>
              <a href="/Admin/About">About</a>
            </li>
          </ul>
        </li>
      </ul>
      <ul class="navbar-nav sidenav-toggler">
        <li class="nav-item">
          <a class="nav-link text-center" id="sidenavToggler">
            <i class="fa fa-fw fa-angle-left"></i>
          </a>
        </li>
      </ul>
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link" href="javascript:void(0)" id="toggleNavColor">
            <i class="fa fa-fw fa-toggle-on" aria-hidden="true"></i> Switch Color Scheme
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/">
            <i class="fa fa-fw fa-home"></i> Return to Homepage
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" data-toggle="modal" data-target="#exampleModal">
            <i class="fa fa-fw fa-sign-out"></i> Logout
          </a>
        </li>
      </ul>
    </div>
  </nav>
  
<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="/Admin">Admin Panel</a>
            </li>
            <li class="breadcrumb-item active">Task Queue</li>
            <li class="breadcrumb-item active">Configuration</li>
        </ol>
        <!-- Area Chart Example-->
        <div class="row">
            <div class="col-12">
                <h2>Task Queue</h2>
                <br>
                <div class="card">
                    <div class="card-header">
                        <ul class="nav nav-tabs card-header-tabs">
                            <li class="nav-item">
                                <a class="nav-link active" data-toggle="tab" href="#options"><i class="fa fa-cog" aria-hidden="true"></i> Configuration</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-toggle="tab" href="#list"><i class="fa fa-list" aria-hidden="true"></i> Task List</a>
                            </li>
                        </ul>
                    </div>
                    <div class="card-body">
                        <div class="tab-content">
                            <div class="tab-pane fade show active" id="options" role="tabpanel" aria-labelledby="pills-home-tab">
                                <form id="taskOptions">
                                    <div class="row form-setting">
                                        <div class="col-md-1 form-label">
                                            <label for="fromName" class="col-form-label col-form-label-sm">Token</label>
                                        </div>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" name="task_queue_token" id="task_queue_token" value="<?php echo $taskOption; ?>" spellcheck="false">
                                        </div>
                                        <div class="col-md-4 option-des"> The task queue authentication token should be consistent with the token in the task queue configuration file conf.yaml. Leaving it blank will disable task queue requests.</div>
                                    </div>
                                    <div class="row form-setting">
                                        <div class="col-md-1 form-label">
                                        </div>
                                        <div class="col-md-4">
                                            <button type="button" class="btn btn-outline-secondary" id="generateToken">Generate Token Randomly</button>
                                            <button type="button" class="btn btn-primary" id="saveTask">Save Settings</button>
                                        </div>
                                        <div class="col-md-4 option-des"> </div>
                                        <br><br><br>
                                    </div>
                                </form>
                            </div>
                            <div class="tab-pane fade" id="list" role="tabpanel" aria-labelledby="pills-profile-tab">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col" class="textCenter">#</th>
                                            <th scope="col" width="50%">Task Name</th>
                                            <th scope="col" class="textCenter">Status</th>
                                            <th scope="col" class="textCenter">Creation Date</th>
                                            <th scope="col" class="textCenter">Created By UID</th>
                                        </tr>
                                    </thead>
                                    <tbody id="listContent">
                                        <?php if(is_array($task) || $task instanceof \think\Collection || $task instanceof \think\Paginator): $i = 0; $__LIST__ = $task;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$t): $mod = ($i % 2 );++$i;?>
                                        <tr id="i-<?php echo $t['id']; ?>" >
                                            <th scope="row" class="textCenter"><?php echo $t['id']; ?></th>
                                            <td><?php echo $t['task_name']; ?></td>
                                            <td class="textCenter"><?php echo $t['status']; ?></td>
                                            <td class="textCenter"><?php echo $t['addtime']; ?></td>
                                            <td class="textCenter"><?php echo $t['uid']; ?></td>
                                        </tr>
                                        <?php endforeach; endif; else: echo "" ;endif; ?>
                                    </tbody>
                                </table>
                                <?php echo $task->render(); ?>
                            </div>
                            <div class="tab-pane fade" id="tools" role="tabpanel" aria-labelledby="pills-profile-tab">
                                ddd
                            </div>
                        </div>
                    </div>
                </div><br>
            </div>
        </div>
        <!-- Example DataTables Card-->
    </div>
    <!-- /.container-fluid-->
</div>

  <footer class="sticky-footer">
    <div class="container">
      <div class="text-center">
        <small>Copyright © ZTFAS by Zhanghao Cai;</small>
      </div>
    </div>
  </footer>
  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fa fa-angle-up"></i>
  </a>
  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Confirmation</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Click the “Logout” button to exit the current account.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="/Member/LogOut">Logout</a>
        </div>
      </div>
    </div>
  </div>
  <script src="/static/js/jquery.min.js"></script>
  <script src="/static/js/bootstrap4/bootstrap.bundle.min.js"></script>
  <!-- Core plugin JavaScript -->
  <script src="/static/js/chart.js/Chart.min.js"></script>
  <!-- Custom scripts for all pages -->
  <script src="/static/js/sb-admin.min.js"></script>
  <script type="text/javascript" src="/static/js/toastr.min.js"></script>
  
<script src="/static/js/admin/summernote.min.js"></script>
<script src="/static/js/admin/summernote-zh-CN.min.js"></script>
<script src="/static/js/admin/task.js"></script>

</body>
</html>