<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:74:"/www/wwwroot/caigou-netdisk.mcbar.cc/application/index/view/home/home.html";i:1739203202;s:76:"/www/wwwroot/caigou-netdisk.mcbar.cc/application/index/view/navbar_home.html";i:1739202684;}*/ ?>
<!doctype html>
<html lang="zh_cn" data-ng-app="FileManagerApp">
	<head>
		<meta name="viewport" content="initial-scale=1.0, user-scalable=no">
		<meta charset="utf-8">
        <meta name="theme-color" content="#4e64d9"/>
		<title>My File - <?php echo $options['siteName']; ?></title>
		<script src="/static/js/angular.min.js"></script>
		<script src="/static/js/angular-translate.min.js"></script>
		<script src="/static/js/jquery.min.js"></script>
		<link rel="stylesheet" href="/static/css/bootstrap.min.css" />
		<link rel="stylesheet" href="/static/css/material.css" />
		<script src="/static/js/bootstrap.min.js"></script>
		<link rel="stylesheet" href="/static/css/font-awesome.min.css">
		<link href="/static/css/angular-filemanager.min.css" rel="stylesheet">
		<link href="/static/css/toastr.min.css" rel="stylesheet">
		<script type="text/javascript" src="/static/js/toastr.min.js"></script>
		<script src="/static/js/angular-filemanager.min.js"></script>
		<link rel="stylesheet" href="/static/css/photoswipe.css"> 
		<link rel="stylesheet" href="/static/css/default-skin/default-skin.css"> 
		<script type="text/javascript">
		uploadConfig={
			saveType : "<?php echo $policyData['policy_type']; ?>",
			maxSize : "<?php echo $policyData['max_size']; ?>mb",
			allowedType: [ 
				<?php echo $extLimit; ?>
			],
			allowSource : "<?php echo $policyData['origin_link']; ?>",
			upUrl : "<?php echo $policyData['server']; ?>",
			allowShare:"<?php echo $groupData['allow_share']; ?>",
            allowRemoteDownload:"<?php echo explode(",",$groupData['aria2'])[0]; ?>",
            allowTorrentDownload:"<?php echo explode(",",$groupData['aria2'])[1]; ?>",
		};
		</script>
		<script src="/static/js/home.js"></script>
	</head>
	<body class="ng-cloak">
		<div id="container">
			<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <a class="navbar-brand waves-light" href="/">
      </a>
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
    </div>
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a href="#" class="dropdown-toggle avatar-a waves-light" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
            <img src="/Member/Avatar/<?php echo $userInfo['uid']; ?>/s" class="img-circle avatar-s"> <?php echo $userInfo['userNick']; ?> <span class="caret"></span>
          </a>
          <ul class="dropdown-menu">
            <li><a href="/Profile/<?php echo $userInfo['uid']; ?>">Profile</a></li>
            <li><a href="/Member/Setting">Settings</a></li>
            <?php if($userInfo['groupId'] == '1'): ?>
            <li><a href="/Admin">Admin Panel</a></li>
            <?php endif; ?>
            <li role="separator" class="divider"></li>
            <li><a href="/Member/LogOut">Logout</a></li>
          </ul>
        </li>
        <li class="mobile-addition">
          <a href="/Share/My" role="button" aria-haspopup="true"><i class="fa fa-share-alt" aria-hidden="true"></i> My Shares</a>
        </li>
        <li class="mobile-addition">
          <a href="/Explore/Search" role="button" aria-haspopup="true"><i class="fa fa-search" aria-hidden="true"></i> Search Shares</a>
        </li>
        <li class="mobile-addition">
          <a href="/Home/Album" role="button" aria-haspopup="true"><i class="fa fa-picture-o" aria-hidden="true"></i> Albums</a>
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>

<!-- Modal -->
<div class="modal fade" id="upload_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" onclick="closeUpload()" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
          <span class="sr-only">Close</span>
        </button>
        <h4 class="modal-title" id="myModalLabel">Upload File</h4>
      </div>
      <div class="modal-body">
        <div class="row" style="margin-top: 20px;">
          <input type="hidden" id="domain" value="http://7xocov.com1.z0.glb.clouddn.com/">
          <input type="hidden" id="uptoken_url" value="uptoken">
          <div class="up_button col-md-4">
            <div id="container">
              <button class="btn btn-raised btn-info btn-lg upload_button waves-light" id="pickfiles">
                <i class="glyphicon glyphicon-plus"></i>
                <span id="up_text"></span>
              </button>
            </div>
          </div>
          <div style="display:none" id="success" class="indo col-md-8">
            <div class="alert alert-success">
              All files processed in queue
            </div>
          </div>
          <div class="col-md-12" align="center">
            <div class="info_box" id="info_box">
              <br>
              <div class="drag_info">
                <span class="info_icon"><i class="glyphicon glyphicon-inbox"></i></span>
                <div class="info_text">Drag files here to start uploading</div>
              </div>
            </div>
            <div class="upload_box" style="display:none;" id="upload_box">
              <table class="table table-striped table-hover text-left" style="display:none;">
                <thead>
                  <tr>
                    <th class="col-md-4">File Name</th>
                    <th class="col-md-2">Size</th>
                    <th class="col-md-6">Progress</th>
                  </tr>
                </thead>
                <tbody id="fsUploadProgress">
                </tbody>
              </table>
            </div>
          </div>
          <div class="container" style="display: none;">
            <div class="body">
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
      </div>
    </div>
  </div>
</div>

<div class="col-md-2 s" id="side">
  <div class="list-group" id="b">
    <a href="/Home" class="list-group-item">
      <i class="fa fa-file" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp; My Files
    </a>
    <a href="/Share/My" class="list-group-item">
      <i class="fa fa-share-alt" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp; My Shares
    </a>
    <a href="/Explore/Search" class="list-group-item">
      <i class="fa fa-search" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp; Search Shares
    </a>
    <a href="/Home/Album" class="list-group-item">
      <i class="fa fa-picture-o" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp; Albums
    </a>
    <?php if((explode(",",$groupData['aria2'])[0] OR explode(",",$groupData['aria2'])[1]) == '1'): ?>
    <a href="/Home/Download" class="list-group-item">
      <i class="fa fa-cloud-download" aria-hidden="true"></i>&nbsp;&nbsp;&nbsp; Remote Download
    </a>
    <?php endif; ?>
  </div>
  <div class="usage" style="visibility: visible; position: absolute; width: 100%; height: 100px; top: auto; bottom: 0px; background-color: #f9f9f9; padding: 15px">
    <div class="usage-title">Capacity Usage:</div>
    <div class="usage-bar">
      <div class="progress progress-striped active">
        <div class="progress-bar" id="memory_bar"></div>
      </div>
    </div>
    <div class="usage-text"><span id="used">--</span>/<span id="total">--</span></div>
  </div>
</div>
			<div class="pswp" tabindex="-1" role="dialog" aria-hidden="true">

    <!-- Background of PhotoSwipe. 
         It's a separate element, as animating opacity is faster than rgba(). -->
    <div class="pswp__bg"></div>
    <!-- Slides wrapper with overflow:hidden. -->
    <div class="pswp__scroll-wrap">
        <!-- Container that holds slides. PhotoSwipe keeps only 3 slides in DOM to save memory. -->
        <div class="pswp__container">
            <!-- don't modify these 3 pswp__item elements, data is added later on -->
            <div class="pswp__item"></div>
            <div class="pswp__item"></div>
            <div class="pswp__item"></div>
        </div>
        <!-- Default (PhotoSwipeUI_Default) interface on top of sliding area. Can be changed. -->
        <div class="pswp__ui pswp__ui--hidden">
            <div class="pswp__top-bar">
                <!--  Controls are self-explanatory. Order can be changed. -->
                <div class="pswp__counter"></div>

                <button class="pswp__button pswp__button--close" title="Close (Esc)"></button>
                <button class="pswp__button pswp__button--fs" title="Toggle fullscreen"></button>
                <button class="pswp__button pswp__button--zoom" title="Zoom in/out"></button>
                <!-- element will get class pswp__preloader--active when preloader is running -->
                <div class="pswp__preloader">
                    <div class="pswp__preloader__icn">
                      <div class="pswp__preloader__cut">
                        <div class="pswp__preloader__donut"></div>
                      </div>
                    </div>
                </div>
            </div>
            <div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
                <div class="pswp__share-tooltip"></div> 
            </div>
            <button class="pswp__button pswp__button--arrow--left" title="Previous (arrow left)">
            </button>
            <button class="pswp__button pswp__button--arrow--right" title="Next (arrow right)">
            </button>
            <div class="pswp__caption">
                <div class="pswp__caption__center"></div>
            </div>
          </div>
        </div>
</div>
		
			<div class="col-md-10 max_height">
			<angular-filemanager></angular-filemanager>
		</div>
	</div>
</body>
          
<script src="/static/js/material.js"></script>

<script type="text/javascript">
upload_load=0;

</script>
<?php echo $options['js_code']; ?>
</html>
