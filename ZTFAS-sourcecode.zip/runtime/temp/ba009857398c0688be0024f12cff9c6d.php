<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:81:"/www/wwwroot/caigou-netdisk.mcbar.cc/application/index/view/admin/add_policy.html";i:1739195750;s:77:"/www/wwwroot/caigou-netdisk.mcbar.cc/application/index/view/header_admin.html";i:1739209039;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Add Upload Policy - <?php echo $options['siteName']; ?></title>
  <!-- Bootstrap core CSS-->
  <link href="/static/css/bootstrap4/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="/static/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="/static/css/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <link href="/static/css/toastr.min.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="/static/css/sb-admin.css" rel="stylesheet">
</head>
<body class="<?php echo $options['admin_color_body']; ?>" id="page-top">
  <!-- Navigation -->
  <nav class="<?php echo $options['admin_color_nav']; ?>" id="mainNav">
    <a class="navbar-brand" href="index.html">ZTFAS Admin</a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
          <a class="nav-link" href="/Admin">
            <i class="fa fa-fw fa-dashboard"></i>
            <span class="nav-link-text">Dashboard</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Settings">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseComponents" data-parent="#exampleAccordion">
            <i class="fa fa-fw fa-wrench"></i>
            <span class="nav-link-text">Settings</span>
          </a>
          <ul class="sidenav-second-level collapse" id="collapseComponents">
            <li>
              <a href="/Admin/Setting">Basic Settings</a>
            </li>
            <li>
              <a href="/Admin/SettingReg">Registration Access</a>
            </li>
            <li>
              <a href="/Admin/SettingMail">Email Sending</a>
            </li>
            <li>
              <a href="/Admin/Config">Configuration File</a>
            </li>
            <li>
              <a href="/Admin/SettingOther">Miscellaneous</a>
            </li>
          </ul>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Templates">
          <a class="nav-link" href="/Admin/Theme">
            <i class="fa fa-fw fa-paint-brush"></i>
            <span class="nav-link-text">Templates</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Files">
          <a class="nav-link" href="/Admin/Files">
            <i class="fa fa-fw fa-folder"></i>
            <span class="nav-link-text">Files</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Shares">
          <a class="nav-link" href="/Admin/Shares">
            <i class="fa fa-fw fa-send"></i>
            <span class="nav-link-text">Shares</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Remote Download">
          <a class="nav-link" href="/Admin/RemoteDownload">
            <i class="fa fa-fw fa-cloud-download"></i>
            <span class="nav-link-text">Remote Download</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Users">
          <a class="nav-link" href="/Admin/Users" data-parent="#user">
            <i class="fa fa-fw fa-user"></i>
            <span class="nav-link-text">Users</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="User Groups">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#group" data-parent="#group">
            <i class="fa fa-fw fa-users"></i>
            <span class="nav-link-text">User Groups</span>
          </a>
          <ul class="sidenav-second-level collapse" id="group">
            <li>
              <a href="/Admin/GroupList">Manage</a>
            </li>
            <li>
              <a href="/Admin/GroupAdd">Add</a>
            </li>
          </ul>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Upload Policies">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#policy" data-parent="#policy">
            <i class="fa fa-fw fa-upload"></i>
            <span class="nav-link-text">Upload Policies</span>
          </a>
          <ul class="sidenav-second-level collapse" id="policy">
            <li>
              <a href="/Admin/PolicyList">Manage</a>
            </li>
            <li>
              <a href="/Admin/PolicyAdd">Add</a>
            </li>
          </ul>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Others">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#else" data-parent="#else">
            <i class="fa fa-fw fa-ellipsis-h"></i>
            <span class="nav-link-text">Others</span>
          </a>
          <ul class="sidenav-second-level collapse" id="else">
            <li>
              <a href="/Admin/Queue">Task Queue</a>
            </li>
            <li>
              <a href="/Admin/Cron">Scheduled Tasks</a>
            </li>
            <li>
              <a href="/Admin/About">About</a>
            </li>
          </ul>
        </li>
      </ul>
      <ul class="navbar-nav sidenav-toggler">
        <li class="nav-item">
          <a class="nav-link text-center" id="sidenavToggler">
            <i class="fa fa-fw fa-angle-left"></i>
          </a>
        </li>
      </ul>
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link" href="javascript:void(0)" id="toggleNavColor">
            <i class="fa fa-fw fa-toggle-on" aria-hidden="true"></i> Switch Color Scheme
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/">
            <i class="fa fa-fw fa-home"></i> Return to Homepage
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" data-toggle="modal" data-target="#exampleModal">
            <i class="fa fa-fw fa-sign-out"></i> Logout
          </a>
        </li>
      </ul>
    </div>
  </nav>
  
<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="/Admin">Admin Panel</a>
            </li>
            <li class="breadcrumb-item">
                <a href="/Admin/PolicyAdd">Upload Policies</a>
            </li>
            <li class="breadcrumb-item active">Add</li>
        </ol>
        <!-- Area Chart Example-->
        <div class="row">
            <div class="col-12">
                <h2>Add Upload Policy</h2>
                <br>
                <div id="choose">
                    <div class="row">
                        <div class="col-md-3 md-2 mt-2">
                            <div class="card cloud">
                                <img class="card-img-top" src="/static/img/local.png" alt="Card image cap">
                                <div class="card-body">
                                    <h5 class="card-title">Local Server</h5>
                                    <p class="card-text">Store files on the same server as the website</p>
                                    <a href="javascript:void()" class="btn btn-primary" id="addLocal">Add</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 md-2 mt-2">
                            <div class="card cloud">
                                <img class="card-img-top" src="/static/img/oss.png" alt="Card image cap">
                                <div class="card-body">
                                    <h5 class="card-title">Alibaba Cloud OSS</h5>
                                    <p class="card-text">Use <a href="https://www.aliyun.com/product/oss?spm=5176.doc54464.765261.286.v2y7Hk" target="_blank">OSS Object Storage</a> to store files, recommended for use with Alibaba Cloud CDN</p>
                                    <a href="javascript:void()" class="btn btn-primary" id="addOss">Add</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mt-2 md-2">
                            <div class="card cloud">
                                <img class="card-img-top" src="/static/img/s3.png" alt="Card image cap">
                                <div class="card-body">
                                    <h5 class="card-title">Amazon S3</h5>
                                    <p class="card-text"><a href="https://aws.amazon.com/cn/s3/?nc1=h_ls" target="_blank">Amazon S3</a> is purpose-built for data storage</p>
                                    <a href="/Admin/PolicyAddS3" class="btn btn-primary">Add</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mt-2 md-2">
                            <div class="card cloud">
                                <img class="card-img-top" src="/static/img/remote.png" alt="Card image cap">
                                <div class="card-body">
                                    <h5 class="card-title">Remote Server (under development)</h5>
                                    <p class="card-text">You can store files on a server different from the main application.</p>
                                    <a href="/Admin/PolicyAddRemote" class="btn btn-primary">Add</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card" id="local" style="display: none">
                    <div class="card-header">
                        Add Local Upload Policy
                    </div>
                    <div class="card-body">
                        <form id="localPolicy">
                            <input type="text" class="form-control" name="policy_type" value="local" style="display: none">
                            <div class="row form-setting">
                                <div class="col-md-1 form-label">
                                    <label for="policy_name" class="col-form-label col-form-label-sm">Upload Policy Name</label>
                                </div>
                                <div class="col-md-4">
                                    <input type="text" class="form-control" name="policy_name" required>
                                </div>
                                <div class="col-md-4 option-des"> The name of the upload policy used to distinguish between different policies.</div>
                            </div>
                            <div class="row form-setting">
                                <div class="col-md-1 form-label">
                                    <label for="policy_name" class="col-form-label col-form-label-sm">Allow External Links</label>
                                </div>
                                <div class="col-md-4">
                                    <input class="" type="radio" name="origin_link" id="local_allowd_origin1" value="1">
                                    <label class="" for="local_allowd_origin1">Allow</label>
                                    &nbsp;&nbsp;&nbsp;
                                    <input class="" type="radio" name="origin_link" id="local_allowd_origin2" value="0" checked>
                                    <label class="" for="local_allowd_origin2">Prohibit</label>
                                </div>
                                <div class="col-md-4 option-des"> Whether to allow obtaining the source URL for the file, recommended to prohibit</div>
                            </div>
                            <div class="row form-setting" id="localOrigin" style="display: none">
                                <div class="col-md-1 form-label">
                                    <label for="url" class="col-form-label col-form-label-sm">External Link Root URL</label>
                                </div>
                                <div class="col-md-4">
                                    <input type="text" class="form-control" name="url" value="<?php echo $options['siteURL']; ?>public/uploads/">
                                </div>
                                <div class="col-md-4 option-des"> Generally keep the default. If you have configured CDN or other products, you can fill in the CDN domain name here, and it must end with "/".</div>
                            </div>
                            <div class="row form-setting">
                                <div class="col-md-1 form-label">
                                    <label for="filetype" class="col-form-label col-form-label-sm">Allowed File Extensions</label>
                                </div>
                                <div class="col-md-4">
                                    <input type="text" class="form-control" name="filetype" value="image/*,jpg,png,gif,bmp,mp4,mp3,txt" spellcheck="false">
                                </div>
                                <div class="col-md-4 option-des"> Separate multiple entries with a comma ","; leaving it blank means no restrictions. If image file types are allowed, please include "image/*" as well.</div>
                            </div>
                            <div class="row form-setting">
                                <div class="col-md-1 form-label ">
                                    <label for="filetype" class="col-form-label col-form-label-sm">Max Size for Single File</label>
                                </div>
                                <div class="col-md-4 input-group mb-3">
                                    <input type="number" class="form-control" name="max_size" spellcheck="false" min="0" value="10" required>
                                    <div class="input-group-append">
                                        <span class="input-group-text" id="basic-addon2">
                                            <select name="sizeTimes" class="selectIn">
                                                <option value="1">B</option>
                                                <option value="1024">KB</option>
                                                <option value="1048576" selected>MB</option>
                                                <option value="1073741824">GB</option>
                                            </select>
                                        </span>
                                    </div>
                                </div>
                                <div class="col-md-4 option-des"> The maximum size allowed for a single uploaded file.</div>
                            </div>
                            <div class="row form-setting">
                                <div class="col-md-1 form-label ">
                                    <label for="filetype" class="col-form-label col-form-label-sm">File Renaming</label>
                                </div>
                                <div class="col-md-4">
                                    <input class="" type="radio" name="autoname" id="oss_autoname1" value="1" checked>
                                    <label class="" for="oss_autoname1">Enable</label>
                                    &nbsp;&nbsp;&nbsp;
                                    <input class="" type="radio" name="autoname" id="oss_autoname2" value="0">
                                    <label class="" for="oss_autoname2">Disable</label>
                                </div>
                                <div class="col-md-4 option-des"> Enable automatic renaming of stored files. Recommended to enable, as renaming will not affect the display name on the user side and helps avoid file name conflicts.</div>
                            </div>
                            <div class="row form-setting" id="oss_autoname_form">
                                <div class="col-md-1 form-label ">
                                    <label for="url" class="col-form-label col-form-label-sm">Renaming Rule</label>
                                </div>
                                <div class="col-md-4">
                                    <input type="text" class="form-control" name="namerule" value="{uid}_{randomkey8}_{originname}" spellcheck="false" required>
                                </div>
                                <div class="col-md-4 option-des"> You can fill in fields from the <a href="javascript:void()" data-toggle="modal" data-target="#varTable">Variable Mapping Table</a>.</div>
                            </div>
                            <div class="row form-setting">
                                <div class="col-md-1 form-label ">
                                    <label for="filetype" class="col-form-label col-form-label-sm">Storage Directory</label>
                                </div>
                                <div class="col-md-4 input-group mb-3">
                                    <input type="text" class="form-control" name="dirrule" spellcheck="false" value="{date}/{uid}" required>
                                </div>
                                <div class="col-md-4 option-des"> Directory where files will be stored. You can use fields from the <a href="javascript:void()" data-toggle="modal" data-target="#varTableFolder">Directory Variable Mapping Table</a>.</div>
                            </div>
                            <div class="row form-setting">
                                <div class="col-md-1 form-label ">
                                </div>
                                <div class="col-md-4">
                                    <button type="submit" class="btn btn-primary" id="saveOss">Save Settings</button>
                                </div>
                                <div class="col-md-4 option-des"> </div>
                                <br> <br>
                            </div>
                        </form>
                    </div>
                    <br>
                </div>
                <div id="oss" style="display: none">  
                    <div class="alert alert-primary" role="alert">
                        After creating a bucket on Aliyun OSS, please perform the following operations, or upload will not work properly.
                        <ul>
                            <li>Go to Bucket Management - Basic Settings - CORS Settings;</li>
                            <li>Create a rule where the origin is “*”, allow all methods, allow headers as “*”, keep others default, and click to save.</li>
                        </ul>
                    </div>
                    <div class="card">
                        <div class="card-header">
                            Add Aliyun OSS Upload Policy
                        </div>
                        <div class="card-body">
                            <form id="ossPolicy">
                                <input type="text" class="form-control" name="policy_type" value="oss" style="display: none">
                                <div class="row form-setting">
                                    <div class="col-md-1 form-label ">
                                        <label for="policy_name" class="col-form-label col-form-label-sm">Upload Policy Name</label>
                                    </div>
                                    <div class="col-md-4">
                                        <input type="text" class="form-control" name="policy_name" required>
                                    </div>
                                    <div class="col-md-4 option-des"> The name of the upload policy used to distinguish between different policies.</div>
                                </div>
                                <div class="row form-setting">
                                    <div class="col-md-1 form-label ">
                                        <label for="ak" class="col-form-label col-form-label-sm">Access Key ID</label>
                                    </div>
                                    <div class="col-md-4">
                                        <input type="text" class="form-control" name="ak" pattern="[^\s]+" title="Please do not include spaces" required>
                                    </div>
                                    <div class="col-md-4 option-des"> Access Key ID for the Alibaba Cloud account, which can be created or viewed in the Alibaba Cloud Control Panel - Access Key Management</div>
                                </div>
                                <div class="row form-setting">
                                    <div class="col-md-1 form-label ">
                                        <label for="sk" class="col-form-label col-form-label-sm">Access Key Secret</label>
                                    </div>
                                    <div class="col-md-4">
                                        <input type="text" class="form-control" name="sk" pattern="[^\s]+" title="Please do not include spaces" required>
                                    </div>
                                    <div class="col-md-4 option-des"> Get this in the same way as the previous item</div>
                                </div>
                                <div class="row form-setting">
                                    <div class="col-md-1 form-label ">
                                        <label for="bucketname" class="col-form-label col-form-label-sm">Bucket Name</label>
                                    </div>
                                    <div class="col-md-4">
                                        <input type="text" class="form-control" name="bucketname" required>
                                    </div>
                                    <div class="col-md-4 option-des"> The Bucket name you fill in when creating the bucket</div>
                                </div>
                                <div class="row form-setting">
                                    <div class="col-md-1 form-label ">
                                        <label for="policy_name" class="col-form-label col-form-label-sm">Read and Write Permission</label>
                                    </div>
                                    <div class="col-md-4">
                                        <input class="" type="radio" name="bucket_private" id="oss_private_1" value="1" checked>
                                        <label class="" for="oss_private_1">Private</label>
                                        &nbsp;&nbsp;&nbsp;
                                        <input class="" type="radio" name="bucket_private" id="oss_private_0" value="0">
                                        <label class="" for="oss_private_0">Public Read</label>
                                    </div>
                                    <div class="col-md-4 option-des"> Keep consistent with the OSS bucket access control settings, recommended to set as private.</div>
                                </div>
                                <div class="row form-setting" id="oss_outlink" style="display: none">
                                    <div class="col-md-1 form-label ">
                                        <label for="policy_name" class="col-form-label col-form-label-sm">Allow External Links</label>
                                    </div>
                                    <div class="col-md-4">
                                        <input class="" type="radio" name="origin_link" id="oss_allowd_origin1" value="1">
                                        <label class="" for="oss_allowd_origin1">Allow</label>
                                        &nbsp;&nbsp;&nbsp;
                                        <input class="" type="radio" name="origin_link" id="oss_allowd_origin2" value="0" checked>
                                        <label class="" for="oss_allowd_origin2">Prohibit</label>
                                    </div>
                                    <div class="col-md-4 option-des"> Whether to allow obtaining the source URL of the file. Recommended to prohibit.</div>
                                </div>
                                <div class="row form-setting">
                                    <div class="col-md-1 form-label ">
                                        <label for="url" class="col-form-label col-form-label-sm">Bucket Domain Name</label>
                                    </div>
                                    <div class="col-md-4">
                                        <input type="text" class="form-control" name="url" value="http(s)://" required>
                                    </div>
                                    <div class="col-md-4 option-des"> The domain name bound to the OSS bucket for file download and access; must end with "/" (Recommended to use with Alibaba Cloud CDN; fill in the CDN domain name here).</div>
                                </div>
                                <div class="row form-setting">
                                    <div class="col-md-1 form-label ">
                                        <label for="server" class="col-form-label col-form-label-sm">Upload Domain Name</label>
                                    </div>
                                    <div class="col-md-4">
                                        <input type="text" class="form-control" name="server" value="http(s)://" required>
                                    </div>
                                    <div class="col-md-4 option-des"> The domain name of the OSS bucket; generally should be the same as the previous entry. (If the previous entry is the CDN domain name, then this entry should not be the same).</div>
                                </div>
                                <div class="row form-setting">
                                    <div class="col-md-1 form-label ">
                                        <label for="filetype" class="col-form-label col-form-label-sm">Allowed File Extensions</label>
                                    </div>
                                    <div class="col-md-4">
                                        <input type="text" class="form-control" name="filetype" value="image/*,jpg,png,gif,bmp,mp4,mp3,txt" spellcheck="false">
                                    </div>
                                    <div class="col-md-4 option-des"> Separate multiple entries with a comma ","; leaving it blank means no restrictions. If image file types are allowed, please include "image/*" as an additional entry.</div>
                                </div>
                                <div class="row form-setting">
                                    <div class="col-md-1 form-label ">
                                        <label for="filetype" class="col-form-label col-form-label-sm">Max Size for Single File</label>
                                    </div>
                                    <div class="col-md-4 input-group mb-3">
                                        <input type="number" class="form-control" name="max_size" spellcheck="false" min="0" value="10" required>
                                        <div class="input-group-append">
                                            <span class="input-group-text" id="basic-addon2">
                                                <select name="sizeTimes" class="selectIn">
                                                    <option value="1">B</option>
                                                    <option value="1024">KB</option>
                                                    <option value="1048576" selected>MB</option>
                                                    <option value="1073741824">GB</option>
                                                </select>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="col-md-4 option-des"> The maximum size allowed for a single uploaded file.</div>
                                </div>
                                <div class="row form-setting">
                                    <div class="col-md-1 form-label ">
                                        <label for="filetype" class="col-form-label col-form-label-sm">File Renaming</label>
                                    </div>
                                    <div class="col-md-4">
                                        <input class="" type="radio" name="autoname" id="oss_autoname1" value="1" checked>
                                        <label class="" for="oss_autoname1">Enable</label>
                                        &nbsp;&nbsp;&nbsp;
                                        <input class="" type="radio" name="autoname" id="oss_autoname2" value="0">
                                        <label class="" for="oss_autoname2">Disable</label>
                                    </div>
                                    <div class="col-md-4 option-des"> Enable automatic renaming of stored files. It is recommended to enable this to avoid file name conflicts without affecting the displayed name on the user side.</div>
                                </div>
                                <div class="row form-setting" id="oss_autoname_form">
                                    <div class="col-md-1 form-label ">
                                        <label for="url" class="col-form-label col-form-label-sm">Renaming Rule</label>
                                    </div>
                                    <div class="col-md-4">
                                        <input type="text" class="form-control" name="namerule" value="{uid}_{randomkey8}_{originname}" spellcheck="false" required>
                                    </div>
                                    <div class="col-md-4 option-des"> You can use fields from the <a href="javascript:void()" data-toggle="modal" data-target="#varTable">Variable Mapping Table</a> for filling this.</div>
                                </div>
                                <div class="row form-setting">
                                    <div class="col-md-1 form-label ">
                                    </div>
                                    <div class="col-md-4">
                                        <button type="submit" class="btn btn-primary" id="saveOss">Save Settings</button>
                                    </div>
                                    <div class="col-md-4 option-des"> </div>
                                    <br> <br>
                                </div>
                            </form>
                        </div>
                    </div>
                    <br>
                </div>
                <div id="oss" style="display: none">  
                    <div class="alert alert-primary" role="alert">
                        After creating a bucket on Aliyun OSS, please perform the following operations; otherwise, uploads will not work properly.
                        <ul>
                            <li>Go to Bucket Management - Basic Settings - CORS Settings;</li>
                            <li>Create a rule where the origin is “*”, allow all methods, allow headers as “*”, keep others default, and click to save.</li>
                        </ul>
                    </div>
                    <div class="card">
                        <div class="card-header">
                            Add Aliyun OSS Upload Policy
                        </div>
                        <div class="card-body">
                            <!-- The form for adding the OSS upload policy, similar to above -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Example DataTables Card-->
    </div>
    <!-- /.container-fluid-->
</div>
<!-- /.content-wrapper-->
<div class="modal fade" tabindex="-1" role="dialog" id="varTable">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Variable Mapping Table for Auto-Renaming</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Variable Field</th>
                                <th>Explanation</th>
                                <th>Example</th>
                                <th>Applicable Range</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>{date}</td>
                                <td>Upload Date</td>
                                <td>20180118</td>
                                <td>All</td>
                            </tr>
                            <tr>
                                <td>{datetime}</td>
                                <td>Upload Date and Time</td>
                                <td>20180118121049</td>
                                <td>All</td>
                            </tr>
                            <tr>
                                <td>{uid}</td>
                                <td>Uploader UID</td>
                                <td>154</td>
                                <td>All</td>
                            </tr>
                            <tr>
                                <td>{timestamp}</td>
                                <td>Timestamp</td>
                                <td>1516277624</td>
                                <td>All</td>
                            </tr>
                            <tr>
                                <td>{randomkey16}</td>
                                <td>16-character random key</td>
                                <td>16D8lhjErTDWAQjW</td>
                                <td>All</td>
                            </tr>
                            <tr>
                                <td>{randomkey8}</td>
                                <td>8-character random key</td>
                                <td>hM4Tpdh6</td>
                                <td>All</td>
                            </tr>
                            <tr>
                                <td>{originname}</td>
                                <td>Original File Name</td>
                                <td>plus1s.jpg</td>
                                <td>All</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" tabindex="-1" role="dialog" id="varTableFolder">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Directory Variable Mapping Table</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Variable Field</th>
                                <th>Explanation</th>
                                <th>Example</th>
                                <th>Applicable Range</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>{date}</td>
                                <td>Upload Date</td>
                                <td>20180118</td>
                                <td>All</td>
                            </tr>
                            <tr>
                                <td>{datetime}</td>
                                <td>Upload Date and Time</td>
                                <td>20180118121049</td>
                                <td>All</td>
                            </tr>
                            <tr>
                                <td>{uid}</td>
                                <td>Uploader UID</td>
                                <td>154</td>
                                <td>All</td>
                            </tr>
                            <tr>
                                <td>{timestamp}</td>
                                <td>Timestamp</td>
                                <td>1516277624</td>
                                <td>All</td>
                            </tr>
                            <tr>
                                <td>{randomkey16}</td>
                                <td>16-character random key</td>
                                <td>16D8lhjErTDWAQjW</td>
                                <td>All</td>
                            </tr>
                            <tr>
                                <td>{randomkey8}</td>
                                <td>8-character random key</td>
                                <td>hM4Tpdh6</td>
                                <td>All</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>


  <footer class="sticky-footer">
    <div class="container">
      <div class="text-center">
        <small>Copyright © ZTFAS by Zhanghao Cai;</small>
      </div>
    </div>
  </footer>
  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fa fa-angle-up"></i>
  </a>
  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Confirmation</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Click the “Logout” button to exit the current account.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="/Member/LogOut">Logout</a>
        </div>
      </div>
    </div>
  </div>
  <script src="/static/js/jquery.min.js"></script>
  <script src="/static/js/bootstrap4/bootstrap.bundle.min.js"></script>
  <!-- Core plugin JavaScript -->
  <script src="/static/js/chart.js/Chart.min.js"></script>
  <!-- Custom scripts for all pages -->
  <script src="/static/js/sb-admin.min.js"></script>
  <script type="text/javascript" src="/static/js/toastr.min.js"></script>
  
<script src="/static/js/admin/add_policy.js"></script>
<script type="text/javascript">
</script>

</body>
</html>