<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:80:"/www/wwwroot/caigou-netdisk.mcbar.cc/application/index/view/admin/user_list.html";i:1739202308;s:77:"/www/wwwroot/caigou-netdisk.mcbar.cc/application/index/view/header_admin.html";i:1739209039;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>User List - <?php echo $options['siteName']; ?></title>
  <!-- Bootstrap core CSS-->
  <link href="/static/css/bootstrap4/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="/static/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="/static/css/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <link href="/static/css/toastr.min.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="/static/css/sb-admin.css" rel="stylesheet">
</head>
<body class="<?php echo $options['admin_color_body']; ?>" id="page-top">
  <!-- Navigation -->
  <nav class="<?php echo $options['admin_color_nav']; ?>" id="mainNav">
    <a class="navbar-brand" href="index.html">ZTFAS Admin</a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
          <a class="nav-link" href="/Admin">
            <i class="fa fa-fw fa-dashboard"></i>
            <span class="nav-link-text">Dashboard</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Settings">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseComponents" data-parent="#exampleAccordion">
            <i class="fa fa-fw fa-wrench"></i>
            <span class="nav-link-text">Settings</span>
          </a>
          <ul class="sidenav-second-level collapse" id="collapseComponents">
            <li>
              <a href="/Admin/Setting">Basic Settings</a>
            </li>
            <li>
              <a href="/Admin/SettingReg">Registration Access</a>
            </li>
            <li>
              <a href="/Admin/SettingMail">Email Sending</a>
            </li>
            <li>
              <a href="/Admin/Config">Configuration File</a>
            </li>
            <li>
              <a href="/Admin/SettingOther">Miscellaneous</a>
            </li>
          </ul>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Templates">
          <a class="nav-link" href="/Admin/Theme">
            <i class="fa fa-fw fa-paint-brush"></i>
            <span class="nav-link-text">Templates</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Files">
          <a class="nav-link" href="/Admin/Files">
            <i class="fa fa-fw fa-folder"></i>
            <span class="nav-link-text">Files</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Shares">
          <a class="nav-link" href="/Admin/Shares">
            <i class="fa fa-fw fa-send"></i>
            <span class="nav-link-text">Shares</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Remote Download">
          <a class="nav-link" href="/Admin/RemoteDownload">
            <i class="fa fa-fw fa-cloud-download"></i>
            <span class="nav-link-text">Remote Download</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Users">
          <a class="nav-link" href="/Admin/Users" data-parent="#user">
            <i class="fa fa-fw fa-user"></i>
            <span class="nav-link-text">Users</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="User Groups">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#group" data-parent="#group">
            <i class="fa fa-fw fa-users"></i>
            <span class="nav-link-text">User Groups</span>
          </a>
          <ul class="sidenav-second-level collapse" id="group">
            <li>
              <a href="/Admin/GroupList">Manage</a>
            </li>
            <li>
              <a href="/Admin/GroupAdd">Add</a>
            </li>
          </ul>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Upload Policies">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#policy" data-parent="#policy">
            <i class="fa fa-fw fa-upload"></i>
            <span class="nav-link-text">Upload Policies</span>
          </a>
          <ul class="sidenav-second-level collapse" id="policy">
            <li>
              <a href="/Admin/PolicyList">Manage</a>
            </li>
            <li>
              <a href="/Admin/PolicyAdd">Add</a>
            </li>
          </ul>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Others">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#else" data-parent="#else">
            <i class="fa fa-fw fa-ellipsis-h"></i>
            <span class="nav-link-text">Others</span>
          </a>
          <ul class="sidenav-second-level collapse" id="else">
            <li>
              <a href="/Admin/Queue">Task Queue</a>
            </li>
            <li>
              <a href="/Admin/Cron">Scheduled Tasks</a>
            </li>
            <li>
              <a href="/Admin/About">About</a>
            </li>
          </ul>
        </li>
      </ul>
      <ul class="navbar-nav sidenav-toggler">
        <li class="nav-item">
          <a class="nav-link text-center" id="sidenavToggler">
            <i class="fa fa-fw fa-angle-left"></i>
          </a>
        </li>
      </ul>
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link" href="javascript:void(0)" id="toggleNavColor">
            <i class="fa fa-fw fa-toggle-on" aria-hidden="true"></i> Switch Color Scheme
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/">
            <i class="fa fa-fw fa-home"></i> Return to Homepage
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" data-toggle="modal" data-target="#exampleModal">
            <i class="fa fa-fw fa-sign-out"></i> Logout
          </a>
        </li>
      </ul>
    </div>
  </nav>
  
<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="/Admin">Admin Panel</a>
            </li>
            <li class="breadcrumb-item active">Users</li>
        </ol>
        <!-- Area Chart Example-->
        <div class="row">
            <div class="col-12">
                <h2>Users <button class="btn btn-secondary btn-sm" data-toggle="modal" data-target="#addUser"><li class="fa fa-plus"></li></button></h2>
                <br>
                <div class="card mb-3">
                    <div class="card-header">
                        <i class="fa fa-tags"></i> Conditional Search
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-1 form-label-search mb-2">Sort By</div>
                            <div class="col-md-10">
                                <ul class="nav nav-pills" id="order">
                                    <li class="nav-item">
                                        <a class="nav-link selectLab" href="javascript:void()" data-method="user_nick ASC">Username</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link selectLab" href="javascript:void()" data-method="id DESC">Registration Date</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link selectLab" href="javascript:void()" data-method="used_storage DESC">Used Space</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-1 form-label-search mb-2">User Group</div>
                            <div class="col-md-10">
                                <ul class="nav nav-pills" id="groupS">
                                    <li class="nav-item">
                                        <a class="nav-link selectLab" href="javascript:void()" data-group="">All</a>
                                    </li>
                                    <?php if(is_array($group) || $group instanceof \think\Collection || $group instanceof \think\Paginator): $i = 0; $__LIST__ = $group;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$group): $mod = ($i % 2 );++$i;?>
                                    <li class="nav-item">
                                        <a class="nav-link selectLab" href="javascript:void()" data-group="<?php echo $group['id']; ?>"><?php echo $group['group_name']; ?></a>
                                    </li>
                                    <?php endforeach; endif; else: echo "" ;endif; ?>
                                </ul>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-1 form-label-search mb-2">User Status</div>
                            <div class="col-md-10">
                                <ul class="nav nav-pills" id="status">
                                    <li class="nav-item">
                                        <a class="nav-link selectLab" href="javascript:void()" data-status="">All</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link selectLab" href="javascript:void()" data-status="1">Active</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link selectLab" href="javascript:void()" data-status="2">Banned/Inactive</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="row" style="margin-top: 5px;">
                            <div class="col-1 form-label-search mb-2">Advanced Search</div>
                            <div class="col-md-10">
                                <div class="row">
                                    <div class="col-md-2">
                                        <select class="form-control form-control-sm" id="searchColUser">
                                            <option value="id">User UID</option>
                                            <option value="user_nick">Username</option>
                                            <option value="user_date">Registration Date</option>
                                            <option value="user_email">Email</option>
                                            <option value="group_primary">Initial User Group</option>
                                            <option value="user_activation_key">Email Activation Key</option>
                                            <option value="used_storage">Used Space</option>
                                            <option value="delay_time">User Group Expiration Date</option>
                                            <option value="avatar">Avatar Identifier</option>
                                            <option value="profile">Profile Status</option>
                                        </select>
                                    </div>
                                    <div class="col-md-2">
                                        <input type="text" class="form-control form-control-sm" placeholder="Search Expression" id="searchValueUser">
                                    </div>
                                    <div class="col-md-1">
                                        <button type="button" class="btn btn-primary btn-sm" id="applySearch">Apply</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card mb-3">
                    <div class="card-header">
                        <i class="fa fa-table"></i> User List
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <div id="dataTable_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4">
                                <div class="row">
                                    <div class="col-sm-12 col-md-6">
                                        <div class="dataTables_length">
                                            <label>Show 
                                                <select id="dataTable_length" aria-controls="dataTable" class="form-control form-control-sm">
                                                    <option value="10">10</option>
                                                    <option value="25">25</option>
                                                    <option value="50">50</option>
                                                    <option value="100">100</option>
                                                </select> entries</label>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-6">
                                        <div id="dataTable_filter" class="dataTables_filter">
                                            <label>Search:<input type="search" class="form-control form-control-sm" placeholder="" id="searchFrom"></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="table-responsive">
                                            <table class="table table-bordered dataTable" id="dataTable" width="100%" cellspacing="0" role="grid" aria-describedby="dataTable_info" style="width: 100%;">
                                                <thead>
                                                    <tr role="row" class="textCenter">
                                                        <th><input type="checkbox" data-type="all"></th>
                                                        <th>UID</th>
                                                        <th>Nickname</th>
                                                        <th class="textCenter">Email</th>
                                                        <th class="textCenter">User Group</th>
                                                        <th class="textCenter">Storage Used</th>
                                                        <th class="textCenter">Status</th>
                                                        <th class="textCenter">Action</th>
                                                    </tr>
                                                </thead>
                                                <tfoot>
                                                    <tr>
                                                        <th rowspan="1" colspan="1" class="textCenter"><input type="checkbox" data-type="all"></th>
                                                        <th rowspan="1" colspan="1" class="textCenter">UID</th>
                                                        <th rowspan="1" colspan="1" class="textCenter">Nickname</th>
                                                        <th rowspan="1" colspan="1" class="textCenter">Email</th>
                                                        <th rowspan="1" colspan="1" class="textCenter">User Group</th>
                                                        <th rowspan="1" colspan="1" class="textCenter">Storage Used</th>
                                                        <th rowspan="1" colspan="1" class="textCenter">Status</th>
                                                        <th rowspan="1" colspan="1" class="textCenter">Action</th>
                                                    </tr>
                                                </tfoot>
                                                <tbody>
                                                    <tr role="row" class="odd" id="userList">
                                                        <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$user): $mod = ($i % 2 );++$i;?>
                                                        <tr role="row" class="odd">
                                                            <td class="sorting_1 textCenter"><input type="checkbox" data-type="mark" data-id="<?php echo $user['id']; ?>"></td>
                                                            <td class="textCenter"><?php echo $user['id']; ?></td>
                                                            <td class="textCenter"><?php echo $user['user_nick']; ?></td>
                                                            <td class="textCenter"><?php echo $user['user_email']; ?></td>
                                                            <td class="textCenter"><?php echo $originList[$key]["group"]["group_name"]; ?></td>
                                                            <td class="textCenter"><?php echo countSize($user['used_storage']); ?></td>
                                                            <td class="textCenter">
                                                                <?php if($user['user_status'] == '0'): ?>
                                                                <span class="order_success">Active</span>
                                                                <?php else: ?>
                                                                <span class="order_warning">Banned/Inactive</span>
                                                                <?php endif; ?>
                                                            </td>
                                                            <td class="textCenter">
                                                                <button type="button" class="btn btn-secondary fix" data-toggle="tooltip" data-placement="top" title="Delete" data-action="delete" data-id="<?php echo $user['id']; ?>" data-unable="<?php if($user['used_storage'] == '0'): ?>0<?php else: ?>1<?php endif; ?>"><i class="fa fa-trash" aria-hidden="true"></i></button>
                                                                <button type="button" class="btn btn-secondary fix" data-toggle="tooltip" data-placement="top" title="Edit" data-action="edit" data-id="<?php echo $user['id']; ?>"><i class="fa fa-id-card" aria-hidden="true"></i></button>
                                                                <button type="button" class="btn btn-secondary fix" data-toggle="tooltip" data-placement="top" title="Ban/Unban" data-action="ban" data-id="<?php echo $user['id']; ?>"><i class="fa fa-ban" aria-hidden="true"></i></button>
                                                            </td>
                                                        </tr>
                                                        <?php endforeach; endif; else: echo "" ;endif; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="col-md-5 mb-2 mt-2" style="display: none" id="del">
                                            <button type="button" class="btn btn-danger" id="delAll"><i class="fa fa-trash" aria-hidden="true"></i> Delete Selected Users</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-12 col-md-5">
                                        <div class="dataTables_info" id="dataTable_info" role="status" aria-live="polite">Showing page <?php echo $pageNow; ?> of <?php echo $pageTotal; ?> pages with <?php echo $dataTotal; ?> entries.</div>
                                    </div>
                                    <div class="col-sm-12 col-md-7">
                                        <div class="dataTables_paginate paging_simple_numbers" id="dataTable_paginate">
                                            <?php echo $list->render(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Example DataTables Card-->
        </div>
        <!-- /.container-fluid-->
    </div>
    <div class="modal fade bd-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true" id="editUser">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">User Details</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="editUserForm">
                        <div class="form-group">
                            <label>Avatar</label>
                            <img src="" id="user_avatar">
                        </div>
                        <div class="form-group">
                            <label for="name">UID</label>
                            <input type="text" name="uid" id="uid" style="display: none;">
                            <input class="form-control" id="id" type="text" value="17" readonly>
                        </div>
                        <div class="form-group">
                            <label for="lovelyname">Nickname</label>
                            <input type="text" class="form-control" id="user_nick" name="user_nick" required>
                        </div>
                        <div class="form-group">
                            <label for="InputPassword1">Password</label>
                            <input type="password" class="form-control" id="user_pass" name="user_pass" placeholder="Leave empty to keep the current password">
                        </div>
                        <div class="form-group">
                            <label for="InputEmail1">Email</label>
                            <input type="email" class="form-control" id="user_email" name="user_email" placeholder="Email" required>
                        </div>
                        <div class="form-group">
                            <label for="date">Registration Date</label>
                            <input class="form-control" id="user_date" type="text" value="2017.12.31" readonly>
                        </div>
                        <div class="form-group">
                            <label for="space">Used Space</label>
                            <input class="form-control" id="used_storage" type="text" value="500M" readonly>
                        </div>
                        <div class="form-group">
                            <label for="openid">Two-Step Verification Key</label>
                            <input type="text" class="form-control" id="two_step" name="two_step" placeholder="Fill 0 to disable two-step verification" required="">
                        </div>
                        <div class="form-group">
                            <label for="inputState">User Status</label>
                            <select class="form-control" id="user_status" name="user_status">
                                <option value="0">Active</option>
                                <option value="1">Banned/Inactive</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="inputState">User Group</label>
                            <select id="user_group" class="form-control" name="user_group">
                                <?php foreach($groups as $g): ?>
                                    <option value="<?php echo $g['id']; ?>"><?php echo $g['group_name']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="inputState">Profile Status</label>
                            <div class="radio">
                                <label>
                                    <input type="radio" name="profile" id="profile1" value="1">
                                    Enable
                                </label>
                                <label>
                                    <input type="radio" name="profile" id="profile0" value="0">
                                    Disable
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" id="editUserSubmit">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade bd-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true" id="addUser">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add User</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="addUserForm">
                        <div class="form-group">
                            <label for="lovelyname">Nickname</label>
                            <input type="text" class="form-control" id="user_nick" name="user_nick" required>
                        </div>
                        <div class="form-group">
                            <label for="InputPassword1">Password</label>
                            <input type="password" class="form-control" id="user_pass" name="user_pass" required>
                        </div>
                        <div class="form-group">
                            <label for="InputEmail1">Email</label>
                            <input type="email" class="form-control" id="user_email" name="user_email" placeholder="Email" required>
                        </div>
                        <div class="form-group">
                            <label for="inputState">User Status</label>
                            <select class="form-control" name="user_status">
                                <option value="0">Active</option>
                                <option value="1">Banned/Inactive</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="inputState">User Group</label>
                            <select class="form-control" name="user_group">
                                <?php foreach($groups as $g): ?>
                                    <option value="<?php echo $g['id']; ?>"><?php echo $g['group_name']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" id="addUserSubmit">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- /.content-wrapper-->

  <footer class="sticky-footer">
    <div class="container">
      <div class="text-center">
        <small>Copyright © ZTFAS by Zhanghao Cai;</small>
      </div>
    </div>
  </footer>
  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fa fa-angle-up"></i>
  </a>
  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Confirmation</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Click the “Logout” button to exit the current account.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="/Member/LogOut">Logout</a>
        </div>
      </div>
    </div>
  </div>
  <script src="/static/js/jquery.min.js"></script>
  <script src="/static/js/bootstrap4/bootstrap.bundle.min.js"></script>
  <!-- Core plugin JavaScript -->
  <script src="/static/js/chart.js/Chart.min.js"></script>
  <!-- Custom scripts for all pages -->
  <script src="/static/js/sb-admin.min.js"></script>
  <script type="text/javascript" src="/static/js/toastr.min.js"></script>
  
<script src="/static/js/admin/users.js"></script>
<script type="text/javascript">
</script>

</body>
</html>