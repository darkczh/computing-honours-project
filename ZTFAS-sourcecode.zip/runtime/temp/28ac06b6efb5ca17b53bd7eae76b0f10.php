<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:77:"/www/wwwroot/caigou-netdisk.mcbar.cc/application/index/view/member/login.html";i:1739209481;s:78:"/www/wwwroot/caigou-netdisk.mcbar.cc/application/index/view/header_public.html";i:1536836016;s:78:"/www/wwwroot/caigou-netdisk.mcbar.cc/application/index/view/navbar_public.html";i:1739202756;}*/ ?>
<html lang="zh-cn" data-ng-app="FileManagerApp">
	<head>
		<meta name="viewport" content="initial-scale=1.0, user-scalable=no">
		<meta charset="utf-8">
		<meta name="theme-color" content="#4e64d9"/>
		<title>Login - <?php echo $options['siteName']; ?></title>
		<!-- third party -->
		<script src="/static/js/jquery.min.js"></script>
		<link rel="stylesheet" href="/static/css/bootstrap.min.css" />
		<link rel="stylesheet" href="/static/css/material.css" />
		<link rel="stylesheet" href="/static/css/animate.css" />
		<script src="/static/js/material.js"></script>
		<script src="/static/js/bootstrap.min.js"></script>
		<link rel="stylesheet" href="/static/css/font-awesome.min.css">
		<!-- /third party -->
		<!-- Comment if you need to use raw source code -->
		<link href="/static/css/toastr.min.css" rel="stylesheet">
		<script type="text/javascript" src="/static/js/toastr.min.js"></script>
		<!-- /Comment if you need to use raw source code -->
		
   <link rel="stylesheet" href="/static/css/login.css" />
    <link rel="stylesheet" href="/static/css/photoswipe.css">
<link rel="stylesheet" href="/static/css/default-skin/default-skin.css">
        <script src="/static/js/jquery.color.js"></script>
    </head>
    <body data-ma-header="teal">
        <nav class="navbar navbar-inverse" >
            <div class="container-fluid">
                <div class="container" >
<div class="navbar-header">
    <div>
        <a class="navbar-brand waves-light" href="/">
            <!-- Brand logo or text can go here -->
        </a>
    </div>
    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
    </button>
</div>

<!-- Collect the nav links, forms, and other content for toggling -->
<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
    <ul class="nav navbar-nav navbar-right">
        <?php if($loginStatus == '1'): ?>
        <li class="dropdown">
            <a href="#" class="dropdown-toggle avatar-a waves-light" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                <img src="/Member/Avatar/<?php echo $userData['id']; ?>/s" class="img-circle avatar-s"> 
                <?php echo $userData['user_nick']; ?> <span class="caret"></span>
            </a>
            <ul class="dropdown-menu">
                <li><a href="/Home">My Files</a></li>
                <li><a href="/Profile/<?php echo $userData['id']; ?>">Profile</a></li>
                <li><a href="/Member/Setting">Settings</a></li>
                <li role="separator" class="divider"></li>
                <li><a href="/Member/LogOut">Logout</a></li>
            </ul>
        </li>
        <?php else: ?>
        <li>
            <a href="/Login" class="dropdown-toggle waves-light" role="button" aria-haspopup="true" aria-expanded="false">
                <i class="fa fa-user mr-1"></i> Login/Register 
            </a>
        </li>
        <?php endif; ?>
    </ul>
</div><!-- /.navbar-collapse -->
                <div class="header-panel shadow-z-2">
                    <div class="container-fluid">
                        <div class="row">
                        </div>
                    </div>
                </div>
                <div class="container main" >
                    <div class="col-md-4"></div>
                    <div class="col-md-4">
                        <div class="jumbotron" id="logForm">
                            <div class="card_top">
                                <div class="row top-color">
                                    <div class="card-top-row">
                                     <div class="login-icon"><i class="fa fa-user-circle-o" aria-hidden="true"></i></div>
                                     <div class="login-text">Log in to enjoy wonderful content</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card_botom">
                                <div class="row bottom-width">
                                <form id="loginForm">
                                    <div class="form-group  label-floating">
                                    <label class="control-label" for="inputEmail">Email</label>
                                    <input type="text" class="form-control" id="inputEmail" name="userMail">
                                    </div>
                                    <div class="form-group  label-floating">
                                    <label class="control-label" for="inputPwd">Password</label>
                                    <input type="password" class="form-control" id="inputPwd" name="userPass">
                                    </div>
                                    <?php if($RegOptions['login_captcha'] == '1'): ?>
                                    <div class="input-group form-group label-floating">
                                    <label class="control-label" for="captcha">Captcha</label>
                                        <input type="text" id="captcha" class="form-control" name="captchaCode">
                                                  <span class="input-group-btn">
                                                      <div class="captcha_img"><?php echo captcha_img(); ?></div>
                                                  </span>
                                   </div>
                                    <?php else: endif; ?>
                                </form> <button class="btn btn-raised btn-primary waves-light" id="loginButton">Login</button>
                                 <div class="link-group">
                                <a href="javascript:void" class="noWave" id="create" data-change="true">Create an account</a><br>
                                <a href="javascript:void" class="noWave" id="forgetSwitch2" data-change="true">Forgot password?</a>
                                </div>
                                </div>
                            </div>
                            </div>
<div class="jumbotron" id="regForm" style="display: none;">
                            <div class="card_top">
                                <div class="row top-color">
                                    <div class="card-top-row">
                                     <div class="login-icon"><i class="fa fa-sign-in" aria-hidden="true"></i></div>
                                     <div class="login-text">Register Account</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card_botom">
                                <div class="row bottom-width">
                                <form id="registerForm">
                                    <div class="form-group  label-floating">
                                    <label class="control-label" for="inputEmail">Email</label>
                                    <input type="text" class="form-control" id="inputEmail" name="username-reg">
                                    </div>
                                    <div class="form-group  label-floating">
                                    <label class="control-label" for="inputPwd">Password</label>
                                    <input type="password" class="form-control" id="inputPwd" name="password-reg">
                                    </div>
                                    <div class="form-group  label-floating">
                                    <label class="control-label" for="inputPwd">Repeat Password</label>
                                    <input type="password" class="form-control" id="inputPwd" name="password-check">
                                    </div>
                                    <?php if($RegOptions['reg_captcha'] == '1'): ?>
                                    <div class="input-group form-group label-floating">
                                    <label class="control-label" for="captcha">Captcha</label>
                                        <input type="text" id="captcha" class="form-control" name="captchaCode">
                                                  <span class="input-group-btn">
                                                      <div class="captcha_img"><?php echo captcha_img(); ?></div>
                                                  </span>
                                   </div>
                                    <?php else: endif; ?>
                                </form> <button class="btn btn-raised btn-primary waves-light" id="regButton">Register</button> <div class="link-group">
                                <a href="javascript:void" class="noWave" id="loginSwitch3" data-change="true">Already have an account? Log in now</a><br>
                                <a href="javascript:void" class="noWave" id="forgetSwitch" data-change="true">Forgot password?</a>
                                </div>
                                </div>
                            </div>
                            </div>
                             <div class="jumbotron" id="emailCheck" style="display: none;">
                            <div class="card_top">
                                <div class="row top-color">
                                    <div class="card-top-row">
                                     <div class="login-icon"><i class="fa fa-envelope" aria-hidden="true"></i></div>
                                     <div class="login-text">Activate Account</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card_botom">
                                <div class="row bottom-width"><br>
                                We have sent a confirmation email to your registered email address. Please visit the activation link in the email to complete the registration. If you haven't received the email, please check your spam folder.<br><br>If you still cannot receive the email, please try changing your registration email or contact the site administrator.
                                </div>
                            </div>
                            </div>
<div class="jumbotron" id="forgetForm" style="display: none;">
                            <div class="card_top">
                                <div class="row top-color">
                                    <div class="card-top-row">
                                     <div class="login-icon"><i class="fa fa-question-circle-o" aria-hidden="true"></i></div>
                                     <div class="login-text">Retrieve Password</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card_botom">
                                <div class="row bottom-width">
                                <form id="forgetPwdForm">
                                    <div class="form-group  label-floating">
                                    <label class="control-label" for="inputEmail">Please enter your email.</label>
                                    <input type="text" class="form-control" id="regEmail" name="regEmail">
                                    </div>
                                    <?php if($RegOptions['forget_captcha'] == '1'): ?>
                                    <div class="input-group form-group label-floating">
                                    <label class="control-label" for="captcha">Captcha</label>
                                        <input type="text" id="captcha" class="form-control" name="captchaCode">
                                                  <span class="input-group-btn">
                                                      <div class="captcha_img"><?php echo captcha_img(); ?></div>
                                                  </span>
                                   </div>
                                    <?php else: endif; ?>
                                </form> <button class="btn btn-raised btn-primary waves-light" id="findMyFuckingPwd">Send Reset Link</button> <div class="link-group">
                                <a href="javascript:void" class="noWave" id="loginSwitch2" data-change="true">Return to login</a><br>
                                </div>
                                </div>
                            </div>
                            </div>
                        </div></div>
                        <div class="col-md-4"></div>
                    </div>
                </div>
            </body>
            <script type="text/javascript">
            </script>
            <script src="/static/js/login.js"> </script>
            <?php echo $options['js_code']; ?>
            
