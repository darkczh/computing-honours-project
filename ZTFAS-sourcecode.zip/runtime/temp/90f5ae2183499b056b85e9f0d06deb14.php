<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:76:"/www/wwwroot/caigou-netdisk.mcbar.cc/application/index/view/admin/theme.html";i:1739202056;s:77:"/www/wwwroot/caigou-netdisk.mcbar.cc/application/index/view/header_admin.html";i:1739209039;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Basic Settings - <?php echo $options['siteName']; ?></title>
  <!-- Bootstrap core CSS-->
  <link href="/static/css/bootstrap4/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="/static/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="/static/css/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <link href="/static/css/toastr.min.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="/static/css/sb-admin.css" rel="stylesheet">
</head>
<body class="<?php echo $options['admin_color_body']; ?>" id="page-top">
  <!-- Navigation -->
  <nav class="<?php echo $options['admin_color_nav']; ?>" id="mainNav">
    <a class="navbar-brand" href="index.html">ZTFAS Admin</a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
          <a class="nav-link" href="/Admin">
            <i class="fa fa-fw fa-dashboard"></i>
            <span class="nav-link-text">Dashboard</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Settings">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseComponents" data-parent="#exampleAccordion">
            <i class="fa fa-fw fa-wrench"></i>
            <span class="nav-link-text">Settings</span>
          </a>
          <ul class="sidenav-second-level collapse" id="collapseComponents">
            <li>
              <a href="/Admin/Setting">Basic Settings</a>
            </li>
            <li>
              <a href="/Admin/SettingReg">Registration Access</a>
            </li>
            <li>
              <a href="/Admin/SettingMail">Email Sending</a>
            </li>
            <li>
              <a href="/Admin/Config">Configuration File</a>
            </li>
            <li>
              <a href="/Admin/SettingOther">Miscellaneous</a>
            </li>
          </ul>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Templates">
          <a class="nav-link" href="/Admin/Theme">
            <i class="fa fa-fw fa-paint-brush"></i>
            <span class="nav-link-text">Templates</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Files">
          <a class="nav-link" href="/Admin/Files">
            <i class="fa fa-fw fa-folder"></i>
            <span class="nav-link-text">Files</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Shares">
          <a class="nav-link" href="/Admin/Shares">
            <i class="fa fa-fw fa-send"></i>
            <span class="nav-link-text">Shares</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Remote Download">
          <a class="nav-link" href="/Admin/RemoteDownload">
            <i class="fa fa-fw fa-cloud-download"></i>
            <span class="nav-link-text">Remote Download</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Users">
          <a class="nav-link" href="/Admin/Users" data-parent="#user">
            <i class="fa fa-fw fa-user"></i>
            <span class="nav-link-text">Users</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="User Groups">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#group" data-parent="#group">
            <i class="fa fa-fw fa-users"></i>
            <span class="nav-link-text">User Groups</span>
          </a>
          <ul class="sidenav-second-level collapse" id="group">
            <li>
              <a href="/Admin/GroupList">Manage</a>
            </li>
            <li>
              <a href="/Admin/GroupAdd">Add</a>
            </li>
          </ul>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Upload Policies">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#policy" data-parent="#policy">
            <i class="fa fa-fw fa-upload"></i>
            <span class="nav-link-text">Upload Policies</span>
          </a>
          <ul class="sidenav-second-level collapse" id="policy">
            <li>
              <a href="/Admin/PolicyList">Manage</a>
            </li>
            <li>
              <a href="/Admin/PolicyAdd">Add</a>
            </li>
          </ul>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Others">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#else" data-parent="#else">
            <i class="fa fa-fw fa-ellipsis-h"></i>
            <span class="nav-link-text">Others</span>
          </a>
          <ul class="sidenav-second-level collapse" id="else">
            <li>
              <a href="/Admin/Queue">Task Queue</a>
            </li>
            <li>
              <a href="/Admin/Cron">Scheduled Tasks</a>
            </li>
            <li>
              <a href="/Admin/About">About</a>
            </li>
          </ul>
        </li>
      </ul>
      <ul class="navbar-nav sidenav-toggler">
        <li class="nav-item">
          <a class="nav-link text-center" id="sidenavToggler">
            <i class="fa fa-fw fa-angle-left"></i>
          </a>
        </li>
      </ul>
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link" href="javascript:void(0)" id="toggleNavColor">
            <i class="fa fa-fw fa-toggle-on" aria-hidden="true"></i> Switch Color Scheme
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/">
            <i class="fa fa-fw fa-home"></i> Return to Homepage
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" data-toggle="modal" data-target="#exampleModal">
            <i class="fa fa-fw fa-sign-out"></i> Logout
          </a>
        </li>
      </ul>
    </div>
  </nav>
  
<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="/Admin">Admin Panel</a>
            </li>
            <li class="breadcrumb-item active">Template</li>
        </ol>
        <!-- Area Chart Example-->
        <div class="row">
            <div class="col-12">
                <h2>Edit Template</h2>
                <p>application/index/view/<?php echo rtrim($path,"/"); ?>/<?php echo $name; ?>.html</p>
                <br><br>
                <div class="row">
                    <div class="col-md-9">
                        <input type="text" id="fileName" value="<?php echo $name; ?>" style="display: none">
                        <textarea rows="15" class="form-control" spellcheck="false" style="font-family: 'Courier New';"><?php echo htmlspecialchars($content); ?></textarea>
                        <br>
                        <button class="btn btn-primary" id="saveTheme">Save</button>
                        <br><br>
                    </div>
                    <div class="col-md-3">
                        <div class="file_side">
                            <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                                <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$file): $mod = ($i % 2 );++$i;?>
                                <a class="nav-link" id="v-pills-home-tab" href="/Admin/Theme/name/<?php echo str_replace(".html","",$file); ?>" role="tab" data-name="<?php echo str_replace(".html","",$file); ?>"><?php echo $file; ?></a>
                                <?php endforeach; endif; else: echo "" ;endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Example DataTables Card-->
        </div>
        <!-- /.container-fluid-->
    </div>
    <!-- /.content-wrapper-->

  <footer class="sticky-footer">
    <div class="container">
      <div class="text-center">
        <small>Copyright © ZTFAS by Zhanghao Cai;</small>
      </div>
    </div>
  </footer>
  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fa fa-angle-up"></i>
  </a>
  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Confirmation</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Click the “Logout” button to exit the current account.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="/Member/LogOut">Logout</a>
        </div>
      </div>
    </div>
  </div>
  <script src="/static/js/jquery.min.js"></script>
  <script src="/static/js/bootstrap4/bootstrap.bundle.min.js"></script>
  <!-- Core plugin JavaScript -->
  <script src="/static/js/chart.js/Chart.min.js"></script>
  <!-- Custom scripts for all pages -->
  <script src="/static/js/sb-admin.min.js"></script>
  <script type="text/javascript" src="/static/js/toastr.min.js"></script>
  
<script src="/static/js/admin/config.js"></script>
<script type="text/javascript">
</script>

</body>
</html>