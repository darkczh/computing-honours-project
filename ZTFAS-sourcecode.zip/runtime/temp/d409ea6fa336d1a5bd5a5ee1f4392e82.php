<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:88:"/www/wwwroot/caigou-netdisk.mcbar.cc/application/index/view/admin/add_policy_remote.html";i:1536836017;s:77:"/www/wwwroot/caigou-netdisk.mcbar.cc/application/index/view/header_admin.html";i:1739209039;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>添加上传策略- <?php echo $options['siteName']; ?></title>
  <!-- Bootstrap core CSS-->
  <link href="/static/css/bootstrap4/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="/static/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="/static/css/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <link href="/static/css/toastr.min.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="/static/css/sb-admin.css" rel="stylesheet">
</head>
<body class="<?php echo $options['admin_color_body']; ?>" id="page-top">
  <!-- Navigation -->
  <nav class="<?php echo $options['admin_color_nav']; ?>" id="mainNav">
    <a class="navbar-brand" href="index.html">ZTFAS Admin</a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
          <a class="nav-link" href="/Admin">
            <i class="fa fa-fw fa-dashboard"></i>
            <span class="nav-link-text">Dashboard</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Settings">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseComponents" data-parent="#exampleAccordion">
            <i class="fa fa-fw fa-wrench"></i>
            <span class="nav-link-text">Settings</span>
          </a>
          <ul class="sidenav-second-level collapse" id="collapseComponents">
            <li>
              <a href="/Admin/Setting">Basic Settings</a>
            </li>
            <li>
              <a href="/Admin/SettingReg">Registration Access</a>
            </li>
            <li>
              <a href="/Admin/SettingMail">Email Sending</a>
            </li>
            <li>
              <a href="/Admin/Config">Configuration File</a>
            </li>
            <li>
              <a href="/Admin/SettingOther">Miscellaneous</a>
            </li>
          </ul>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Templates">
          <a class="nav-link" href="/Admin/Theme">
            <i class="fa fa-fw fa-paint-brush"></i>
            <span class="nav-link-text">Templates</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Files">
          <a class="nav-link" href="/Admin/Files">
            <i class="fa fa-fw fa-folder"></i>
            <span class="nav-link-text">Files</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Shares">
          <a class="nav-link" href="/Admin/Shares">
            <i class="fa fa-fw fa-send"></i>
            <span class="nav-link-text">Shares</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Remote Download">
          <a class="nav-link" href="/Admin/RemoteDownload">
            <i class="fa fa-fw fa-cloud-download"></i>
            <span class="nav-link-text">Remote Download</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Users">
          <a class="nav-link" href="/Admin/Users" data-parent="#user">
            <i class="fa fa-fw fa-user"></i>
            <span class="nav-link-text">Users</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="User Groups">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#group" data-parent="#group">
            <i class="fa fa-fw fa-users"></i>
            <span class="nav-link-text">User Groups</span>
          </a>
          <ul class="sidenav-second-level collapse" id="group">
            <li>
              <a href="/Admin/GroupList">Manage</a>
            </li>
            <li>
              <a href="/Admin/GroupAdd">Add</a>
            </li>
          </ul>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Upload Policies">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#policy" data-parent="#policy">
            <i class="fa fa-fw fa-upload"></i>
            <span class="nav-link-text">Upload Policies</span>
          </a>
          <ul class="sidenav-second-level collapse" id="policy">
            <li>
              <a href="/Admin/PolicyList">Manage</a>
            </li>
            <li>
              <a href="/Admin/PolicyAdd">Add</a>
            </li>
          </ul>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Others">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#else" data-parent="#else">
            <i class="fa fa-fw fa-ellipsis-h"></i>
            <span class="nav-link-text">Others</span>
          </a>
          <ul class="sidenav-second-level collapse" id="else">
            <li>
              <a href="/Admin/Queue">Task Queue</a>
            </li>
            <li>
              <a href="/Admin/Cron">Scheduled Tasks</a>
            </li>
            <li>
              <a href="/Admin/About">About</a>
            </li>
          </ul>
        </li>
      </ul>
      <ul class="navbar-nav sidenav-toggler">
        <li class="nav-item">
          <a class="nav-link text-center" id="sidenavToggler">
            <i class="fa fa-fw fa-angle-left"></i>
          </a>
        </li>
      </ul>
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link" href="javascript:void(0)" id="toggleNavColor">
            <i class="fa fa-fw fa-toggle-on" aria-hidden="true"></i> Switch Color Scheme
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/">
            <i class="fa fa-fw fa-home"></i> Return to Homepage
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" data-toggle="modal" data-target="#exampleModal">
            <i class="fa fa-fw fa-sign-out"></i> Logout
          </a>
        </li>
      </ul>
    </div>
  </nav>
  
<div class="content-wrapper">
  <div class="container-fluid">
    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="/Admin">管理面板</a>
      </li>
      <li class="breadcrumb-item">
        <a href="/Admin/PolicyAdd">上传策略</a>
      </li>
      <li class="breadcrumb-item active">添加</li>
    </ol>
    
    <!-- Area Chart Example-->
    <div class="row">
      <div class="col-12">
        <h2>添加上传策略</h2>
        <br>


        <div class="card" id="s3" >
          <div class="card-header">
            添加远程上传策略
          </div>
          <div class="card-body">
            <form id="qiniuPolicy">
              <input type="text" class="form-control" name="policy_type" value="remote" style="display: none">
              <div class="row form-setting">
                <div class="col-md-1 form-label ">
                  <label for="policy_name" class="col-form-label col-form-label-sm">上传策略名称</label>
                </div>
                <div class="col-md-4"> <input type="text" class="form-control" name="policy_name" required></div>
                <div class="col-md-4 option-des"> 上传策略的名称，用于区别不同策略</div>
              </div>
              
              <div class="row form-setting">
                <div class="col-md-1 form-label ">
                  <label for="ak" class="col-form-label col-form-label-sm">AccessToken </label>
                </div>
                <div class="col-md-4"> <input type="text" class="form-control" name="sk" required></div>
                <div class="col-md-4 option-des"> 默认随机生成，请与远程服务端配置文件中保持一致</div>
              </div>

           <input type="text" class="form-control" name="ak" value="0" style="display: none" required>

             <input type="text" name="bucket_private" value="1" style="display: none">
             <input type="text" name="origin_link" value="0" style="display: none">

              <div class="row form-setting">
                <div class="col-md-1 form-label ">
                  <label for="url" class="col-form-label col-form-label-sm">服务端URL</label>
                </div>
                <div class="col-md-4">
                  <input type="text" class="form-control" name="server" required>
                </div>
                <div class="col-md-4 option-des"> 结尾要加"/"</div>
              </div>

              <div class="row form-setting">
                <div class="col-md-1 form-label ">
                  <label for="url" class="col-form-label col-form-label-sm">下载根URL</label>
                </div>
                <div class="col-md-4">
                  <input type="text" class="form-control" name="url" required>
                </div>
                <div class="col-md-4 option-des"> 一般与上一步保持一致，结尾要加"/"</div>
              </div>

              <div class="row form-setting">
                <div class="col-md-1 form-label ">
                  <label for="filetype" class="col-form-label col-form-label-sm">单文件最大大小</label>
                </div>
                <div class="col-md-4 input-group mb-3">
                  <input type="number" class="form-control" name="max_size"  spellcheck="false" min="0" value="10" required>
                  <div class="input-group-append">
                    <span class="input-group-text" id="basic-addon2">
                      <select name="sizeTimes" class="selectIn">
                        <option value="1">B</option>
                        <option value="1024">KB</option>
                        <option value="1048576" selected>MB</option>
                        <option value="1073741824">GB</option>
                      </select>
                    </span>
                  </div>
                </div>
                <div class="col-md-4 option-des"> 允许上传的单个文件的最大尺寸</div>
              </div>

             <div class="row form-setting">
               <div class="col-md-1 form-label ">
                 <label for="filetype" class="col-form-label col-form-label-sm">文件重命名</label>
               </div>
               <div class="col-md-4">
                 <input class="" type="radio" name="autoname" id="autoname1" value="1" checked>
                 <label class="" for="autoname1" >开启</label>
                 &nbsp;&nbsp;&nbsp;
                 <input class="" type="radio" name="autoname" id="autoname2" value="0" >
                 <label class="" for="autoname2">关闭</label>
               </div>
               <div class="col-md-4 option-des"> 是否对存储的文件自动重命名。推荐开启，重命名不会影响用户端文件名展示，开启后可以避免文件重名</div>
             </div>
             <div class="row form-setting" id="autoname_form" >
               <div class="col-md-1 form-label ">
                 <label for="url" class="col-form-label col-form-label-sm">重命名规则</label>
               </div>
               <div class="col-md-4">
                 <input type="text" class="form-control" name="namerule" value="{uid}_{randomkey8}_{originname}" spellcheck="false" required>
               </div>
               <div class="col-md-4 option-des"> 你可以使用变量对照表中的字段填写</div>
             </div>
             <div class="row form-setting">
               <div class="col-md-1 form-label ">
                 <label for="filetype" class="col-form-label col-form-label-sm">存储目录</label>
               </div>
               <div class="col-md-4 input-group mb-3">
                 <div class="input-group-prepend">
                   <span class="input-group-text" id="basic-addon2">
                     /public/uploads/
                   </span>
                 </div>
                 <input type="text" class="form-control" name="dirrule"  spellcheck="false" value="{date}/{uid}" required>
               </div>
               <div class="col-md-4 option-des"> 文件存放的目录，你可以使用目录变量对照表中的字段填写</div>
             </div>

              
              <div class="row form-setting">
                <div class="col-md-1 form-label ">
                </div>
                <div class="col-md-4"> <button type="submit" class="btn btn-primary" id="saveQiniu">保存设置</button></div>
                <div class="col-md-4 option-des"> </div>
                <br> <br>
              </div>
            </form>
          </div>
          <bn>
        </div>




        <br>
      </div>
    </div>
    
    <!-- Example DataTables Card-->
  </div>
  <!-- /.container-fluid-->
</div>


  <footer class="sticky-footer">
    <div class="container">
      <div class="text-center">
        <small>Copyright © ZTFAS by Zhanghao Cai;</small>
      </div>
    </div>
  </footer>
  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fa fa-angle-up"></i>
  </a>
  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Confirmation</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Click the “Logout” button to exit the current account.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="/Member/LogOut">Logout</a>
        </div>
      </div>
    </div>
  </div>
  <script src="/static/js/jquery.min.js"></script>
  <script src="/static/js/bootstrap4/bootstrap.bundle.min.js"></script>
  <!-- Core plugin JavaScript -->
  <script src="/static/js/chart.js/Chart.min.js"></script>
  <!-- Custom scripts for all pages -->
  <script src="/static/js/sb-admin.min.js"></script>
  <script type="text/javascript" src="/static/js/toastr.min.js"></script>
  
<script src="/static/js/admin/add_policy.js"></script>
<script type="text/javascript">
function randomString(len) {
　　len = len || 32;
　　var $chars = 'ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678';
　　var maxPos = $chars.length;
　　var pwd = '';
　　for (i = 0; i < len; i++) {
　　　　pwd += $chars.charAt(Math.floor(Math.random() * maxPos));
　　}
　　return pwd;
}
$("[name='sk']").val(randomString(32));
</script>

</body>
</html>