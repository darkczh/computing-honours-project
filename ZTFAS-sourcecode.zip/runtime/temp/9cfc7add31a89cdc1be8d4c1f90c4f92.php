<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:76:"/www/wwwroot/caigou-netdisk.mcbar.cc/application/index/view/index/index.html";i:1739204198;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Secure Cloud Storage | ZeroTrust Drive</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --cyber-blue: #2E5BFF;
            --secure-green: #00C853;
            --encrypt-purple: #6200EA;
            --dark-bg: #0F172A;
            --neon-accent: #00F0FF;
        }

        body {
            background: var(--dark-bg);
            color: white;
            font-family: 'Inter', system-ui, sans-serif;
            min-height: 100vh;
            overflow-x: hidden;
        }

        .cyber-border {
            position: relative;
            border: 2px solid var(--neon-accent);
            border-radius: 16px;
            background: rgba(15, 23, 42, 0.9);
            backdrop-filter: blur(12px);
            box-shadow: 0 0 32px rgba(46, 91, 255, 0.2);
        }

        .hero-section {
            text-align: center;
            padding: 6rem 2rem;
            position: relative;
        }

        .cyber-glow {
            text-shadow: 0 0 24px rgba(46, 91, 255, 0.6);
        }

        .security-badge {
            display: inline-block;
            padding: 8px 20px;
            background: linear-gradient(45deg, var(--cyber-blue), var(--encrypt-purple));
            border-radius: 50px;
            font-weight: 600;
            margin: 1rem 0;
        }

        .feature-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 2rem;
            padding: 3rem;
        }

        .security-card {
            border: 1px solid rgba(46, 91, 255, 0.3);
            border-radius: 12px;
            padding: 2rem;
            transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .security-card:hover {
            transform: translateY(-5px);
            background: linear-gradient(145deg, rgba(46, 91, 255, 0.1), rgba(98, 0, 234, 0.1));
        }

        .icon-pulse {
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0% { opacity: 0.8; }
            50% { opacity: 1; text-shadow: 0 0 16px var(--neon-accent); }
            100% { opacity: 0.8; }
        }
    </style>
</head>
<body>
    <main class="cyber-border" style="margin: 5% auto; max-width: 1200px;">
        <section class="hero-section">
            <div class="security-badge">
                <i class="fas fa-shield-alt"></i> ZTFAS BY ZHANGHAO CAI
            </div>
            <h1 class="cyber-glow" style="font-size: 3.5rem; margin-bottom: 1.5rem;">
                ZeroTrust Cloud Storage
            </h1>
            <p style="font-size: 1.2rem; opacity: 0.9; max-width: 800px; margin: 0 auto;">
                Military-grade encrypted storage with real-time threat detection and 
                <span style="color: var(--neon-accent);">endpoint-to-cloud encryption</span>
            </p>

            <div style="margin: 3rem 0;">
                <a href="/Login" class="cyber-border" 
                   style="padding: 1rem 3rem; text-decoration: none; margin: 0 1rem;">
                   <i class="fas fa-fingerprint"></i> Secure Sign Up
                </a>
                <a href="/Home" class="cyber-border" 
                   style="padding: 1rem 3rem; text-decoration: none;">
                   <i class="fas fa-lock"></i> Verified Login
                </a>
            </div>

            <div class="feature-grid">
                <div class="security-card">
                    <i class="fas fa-user-shield icon-pulse" style="color: var(--secure-green); font-size: 2.5rem;"></i>
                    <h3>Zero Trust Architecture</h3>
                    <p style="opacity: 0.8;">Continuous identity verification with multi-factor authentication</p>
                </div>
                
                <div class="security-card">
                    <i class="fas fa-laptop-code icon-pulse" style="color: var(--encrypt-purple); font-size: 2.5rem;"></i>
                    <h3>Endpoint Encryption</h3>
                    <p style="opacity: 0.8;">256-bit AES encryption before data leaves your device</p>
                </div>

                <div class="security-card">
                    <i class="fas fa-cloud-upload-alt icon-pulse" style="color: var(--cyber-blue); font-size: 2.5rem;"></i>
                    <h3>Secure Sync</h3>
                    <p style="opacity: 0.8;">Real-time encrypted synchronization across all devices</p>
                </div>
            </div>
        </section>
    </main>
</body>
</html>