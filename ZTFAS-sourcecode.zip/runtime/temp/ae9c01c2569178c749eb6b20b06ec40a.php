<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:33:"application/index/view/error.html";i:1739202510;s:78:"/www/wwwroot/caigou-netdisk.mcbar.cc/application/index/view/header_public.html";i:1536836016;}*/ ?>
<html lang="zh-cn" data-ng-app="FileManagerApp">
	<head>
		<meta name="viewport" content="initial-scale=1.0, user-scalable=no">
		<meta charset="utf-8">
		<meta name="theme-color" content="#4e64d9"/>
		<title>Error - <?php echo $options['siteName']; ?></title>
		<!-- third party -->
		<script src="/static/js/jquery.min.js"></script>
		<link rel="stylesheet" href="/static/css/bootstrap.min.css" />
		<link rel="stylesheet" href="/static/css/material.css" />
		<link rel="stylesheet" href="/static/css/animate.css" />
		<script src="/static/js/material.js"></script>
		<script src="/static/js/bootstrap.min.js"></script>
		<link rel="stylesheet" href="/static/css/font-awesome.min.css">
		<!-- /third party -->
		<!-- Comment if you need to use raw source code -->
		<link href="/static/css/toastr.min.css" rel="stylesheet">
		<script type="text/javascript" src="/static/js/toastr.min.js"></script>
		<!-- /Comment if you need to use raw source code -->
		
<link rel="stylesheet" href="/static/css/error.css" />
</head>
<body data-ma-header="teal">

<div class="container" align="center">
<header align="left">
<br>
<img src="/static/img/logo_s.png" style="width:192px;">
</header>
    <div class="error_content" >
        <div class="jumbotron animated bounce" style="padding-left:30px;">
            <h1>ERROR ENCOUNTERED</h1>
            <br>
            <p>  <?php echo $msg; ?></p>
            <p><a class="btn btn-primary btn-lg" onclick="history.go(-1);"><< Back</a></p>
        </div>
    </div>
</div>
<?php echo $options['js_code']; ?>
</body>

