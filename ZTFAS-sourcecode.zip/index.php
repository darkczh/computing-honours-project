<?php
define('APP_PATH', __DIR__ . '/application/');
define('BIND_MODULE','index');
require __DIR__ . '/thinkphp/start.php';
